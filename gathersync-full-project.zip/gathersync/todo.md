# GatherSync TODO

## Core Features

- [x] Events list screen with event cards
- [x] Create/edit event functionality
- [x] Interactive calendar with month/year navigation
- [x] Heatmap visualization based on availability
- [x] Best day calculation and highlighting
- [x] Participant management (add/remove)
- [x] Individual participant availability editor
- [x] Day detail view showing who's available
- [x] Range selection for marking availability
- [x] "Unavailable all month" toggle
- [x] AI-powered participant import from natural text
- [x] Event history save/restore system
- [ ] Group templates for participant lists
- [x] Local storage persistence with AsyncStorage
- [x] Share event functionality
- [x] Delete event functionality
- [x] Custom app icon and branding
- [x] Haptic feedback on interactions
- [x] Smooth animations and transitions
- [x] Dark mode support

## Cloud Sync Implementation

- [x] Cloud sync with backend database
- [x] Real-time event updates across devices
- [x] Multi-user collaboration on same event
- [x] Database schema for events and participants
- [x] tRPC API endpoints for CRUD operations
- [x] Hybrid storage layer (local for guests, cloud for authenticated users)
- [x] Login banner encouraging users to enable cloud sync
- [x] Automatic fallback to local storage if cloud fails
- [x] Comprehensive test suite for cloud sync functionality

## Push Notifications

- [x] Database schema for storing user push tokens
- [x] Backend API to register/unregister push tokens
- [x] Notification triggers when availability is updated
- [x] Frontend permission request for notifications
- [x] Expo push notification integration
- [x] Notification handler to navigate to event

## Bugs

- [x] Fix "Failed to create event" error when creating events
- [x] Fix TRPCClientError when fetching events
- [x] Implement hybrid storage with Guest Mode and cloud sync
- [x] Fix day selection to allow easy toggling without creating unwanted ranges

## New Features

- [x] Add visual best day indicator with star icon
- [x] Show participant count badges on calendar days
- [x] Add quick weekend selection button

## New Features

- [x] Add copy event feature to duplicate events
- [x] Add participant notes field for additional context
- [x] Add event reminder notifications

## New Features

- [x] Add export to calendar (.ics file generation)
- [x] Add participant status badges showing response status
- [x] Add event archive functionality

## New Features

- [x] Add bulk availability import from spreadsheet data
- [x] Add event date finalization with auto-archive
- [x] Add participant invitation link generation and handling

## New Features

- [x] Add recurring event templates
- [x] Automatic event generation from templates
- [x] Recurring event management UI

## New Features

- [x] Add team leader field to events
- [x] Add meeting type (in-person / virtual)
- [x] Add venue details (name, contact, phone)
- [x] Add virtual meeting link (Zoom, etc.)
- [x] Add RSVP deadline field
- [x] Add quick contact buttons (call venue, copy link)

## Bugs

- [x] Fix copy event to prompt for new month/year instead of duplicating same month

## New Features

- [x] Add contact picker integration for adding participants
- [x] Multi-select contacts from phone's contact list
- [x] Contact permission handling
- [x] Searchable contact list with filtering

## New Features

- [x] Add copyright notice to app UI
- [x] Add About/Settings screen with copyright info

## Contact Management

- [x] Add visual indicator (badge/icon) to distinguish contact-imported participants from manual entries
- [x] Update participant data model to track import source
- [x] Display contact icon next to participants imported from phone contacts

## Meeting Details Enhancement

- [x] Add ability to edit meeting details after event creation
- [x] Integrate contact picker for team leader selection
- [x] Integrate contact picker for venue contact selection
- [x] Add edit button/mode for meeting details section

## Participant Communication Enhancement

- [x] Fix contact search to support partial word matching (e.g., "Kiss" finds "Kiss the Barista")
- [x] Add phone number field to participant data model
- [x] Store phone number when adding participants from contacts
- [x] Add call button next to participants with phone numbers
- [x] Add message/SMS button next to participants with phone numbers

## Bug Fixes

- [x] Fix contact search filter to work with encoded name|phone format
- [x] Add call/message buttons to team leader in meeting details
- [x] Add call/message buttons to venue contact in meeting details

## Team Leader Phone Support

- [x] Add teamLeaderPhone field to Event model
- [x] Store phone number when selecting team leader from contacts
- [x] Display team leader phone number in meeting details
- [x] Add call/message buttons to team leader

## Contact Picker Loading Issue

- [x] Fix ContactPickerModal to load all phone contacts (including those without phone numbers)
- [x] Ensure contacts with special characters or single names are displayed
- [x] Verify contact picker shows all contacts that exist in phone's contact list

## Contact Picker Shows Wrong Data

- [ ] Fix ContactPickerModal to load phone contacts instead of event participants
- [ ] Verify contact picker uses Expo Contacts API correctly


## Organizer RSVP Management

- [ ] Add ability to toggle participant RSVP status from event detail screen
- [ ] Show Attending/Not Attending/No Response buttons when tapping participant
- [ ] Allow organizer to set status on behalf of participants (phone RSVPs)
- [ ] Works for both fixed and flexible events


## Fixed Event Feature Implementation

- [x] Add event type selector (Flexible vs Fixed) to create event screen
- [x] Add date picker for fixed events
- [x] Add time picker for fixed events
- [x] Implement RSVP system (Attending/Not Attending/No Response)
- [x] Update event cards to show date/time for fixed events
- [x] Show RSVP summary on event cards
- [x] Update event detail screen with RSVP summary section
- [x] Update edit availability screen to show RSVP buttons for fixed events
- [x] Test creating fixed events end-to-end


## Disable Backend Services for Local Testing

- [x] Remove backend service dependencies from app configuration
- [x] Ensure app works with local AsyncStorage only
- [x] Enable APK build without backend publish requirement


## Restore Templates Feature

- [x] Add Templates button back to Events screen header
- [x] Allow creating new events from existing event templates


## Edit Event Feature

- [x] Add Edit button to event detail screen
- [x] Allow editing event name, date, time, and other details via create-event screen
- [x] Templates now open create-event screen for easy date/time customization


## Edit Date/Time for Fixed Events

- [x] Add date and time pickers to edit-meeting-details screen for fixed events
- [x] Allow changing date and time after event creation
- [x] Save updated date/time to event


## Fix Date/Time Picker Not Responding

- [x] Debug why date/time picker doesn't open when tapping Date/Time fields in edit-meeting-details
- [x] Ensure Pressable triggers correctly on iOS
- [x] Verify DateTimePicker shows properly when state changes


## Fix Date Selection Not Persisting

- [x] Debug why selected date doesn't update the displayed date
- [x] Ensure fixedDate state updates correctly when date is selected
- [x] Verify date changes are saved when user taps Save button


## Sort Events by Date

- [x] Sort events chronologically on Events screen
- [x] Fixed events sorted by date/time
- [x] Flexible events sorted by month/year


## Update Installation Guides for iOS

- [x] Add Expo Go instructions for iOS users
- [x] Explain this is temporary testing solution
- [x] Update Quick Start Card with both Android and iOS options
- [x] Update rollout checklist with Expo Go QR code generation steps

## Post-Demo Priorities

- [ ] Get Apple Developer account ($99/year) for iOS TestFlight distribution
- [ ] Build production iOS app via TestFlight
- [ ] Build production Android APK with proper signing
- [ ] Build production web version optimized for desktop admins
- [ ] Add keyboard shortcuts for power users on desktop
- [ ] Add bulk operations (multi-select participants, batch RSVP)
- [ ] Add analytics and reports for event organizers
- [ ] Add export functionality (CSV, PDF reports)
- [ ] Fix email participants feature (proper formatting)
- [ ] Add SMS participants feature with selection
- [ ] Implement participant invitation links (unique URLs)
- [ ] Add real-time collaboration indicators (who's viewing/editing)

## Login Flow Fix

- [x] Fix login button to navigate to OAuth login page
- [x] Test login flow on desktop and mobile
- [x] Verify redirect back to app after authentication

## Login Banner Not Disappearing

- [x] Debug why login banner still shows after successful Google OAuth
- [x] Fix banner visibility to check isAuthenticated state
- [x] Add OAuth redirect with loginSuccess parameter
- [x] Add page reload after OAuth to refresh auth state
- [ ] Test login flow end-to-end with user

## Load Contacts Not Working on iPhone

- [ ] Debug why Load Contacts stopped working on Expo Go iOS
- [ ] Check contact permissions are being requested
- [ ] Verify expo-contacts is properly configured
- [ ] Test contact picker on iPhone with Expo Go

## Participant Invitation System (Priority #1 After iOS Launch)

**Problem:** Requiring everyone to download an app is a major adoption barrier. Many people won't download apps, only use email, or aren't tech-savvy.

**Solution:** Allow participants to respond via web link without downloading the app.

### Features to Build:

- [ ] Generate unique invitation links for each participant
- [ ] Create public event view page (no login required)
- [ ] Build simple RSVP interface for marking availability
- [ ] Add email invitation system with personalized links
- [ ] Add SMS invitation option for participants without email
- [ ] Track response status (pending, responded, declined)
- [ ] Show organizer who has/hasn't responded in app
- [ ] Send reminder emails to non-responders
- [ ] Send final date notification to all participants
- [ ] Allow participants to update their response via link
- [ ] Add "Share Event Link" button for organizers
- [ ] Create mobile-optimized web view for participant responses

### User Flow:

**Organizer:**
1. Creates event in app
2. Adds participants with emails/phones
3. Taps "Send Invitations"
4. Chooses email/SMS/both
5. Tracks responses in app
6. Finalizes date and notifies everyone

**Participant (No App):**
1. Receives email/SMS with link
2. Clicks link → Opens in browser
3. Sees event details
4. Marks available dates
5. Submits response
6. Gets confirmation email
7. Receives final date notification

### Technical Implementation:

- [ ] Add `invitationToken` field to Participant model
- [ ] Create `/invite/:token` public route
- [ ] Build participant response API endpoint
- [ ] Set up email service (SendGrid/Mailgun)
- [ ] Create email templates for invitations
- [ ] Add SMS service integration (Twilio)
- [ ] Build public event view component
- [ ] Add response tracking to organizer dashboard
- [ ] Implement reminder scheduling system

## Admin Dashboard (Desktop-Optimized)

### Phase 1: Dashboard Layout
- [ ] Add Admin tab to tab navigation
- [ ] Create admin dashboard home screen
- [ ] Add overview statistics cards
- [ ] Create navigation menu for admin sections

### Phase 2: Event Management
- [ ] Build event list view with filters
- [ ] Add search and sort functionality
- [ ] Create bulk operations (archive, delete, duplicate)
- [ ] Add event status indicators
- [ ] Build quick edit functionality

### Phase 3: Attendance Tracking
- [ ] Create attendance history view
- [ ] Build per-event attendance records
- [ ] Add per-participant attendance stats
- [ ] Create attendance export (CSV, PDF)
- [ ] Add attendance trends visualization

### Phase 4: Participant Management
- [ ] Build master participant list
- [ ] Add participant search and filters
- [ ] Create participant detail view with history
- [ ] Add group/tag management
- [ ] Build participant import/export

### Phase 5: Analytics & Reports
- [ ] Add event success rate metrics
- [ ] Create response rate analytics
- [ ] Build best meeting times analysis
- [ ] Add venue usage statistics
- [ ] Create custom report builder

## Edit Event Bugs (Critical)

- [ ] Fix edit event screen resetting event type to flexible (should preserve fixed/flexible)
- [ ] Fix edit event screen resetting date to today (should preserve original date)
- [ ] Fix edit event screen losing team leader and meeting details after save
- [ ] Fix calendar not showing updated date after editing event

## Hybrid Storage Update Fix

- [x] Fix hybrid storage update to handle cloud-only events
- [x] Update function now fetches full event before updating
- [x] Add cloud events to local storage if missing
- [x] Add comprehensive logging to track save operations

## Storage System Rebuild (In Progress)

### Phase 1: Local Storage Service
- [x] Implement LocalStorageService class
- [x] Add getAll() method
- [x] Add getById() method
- [x] Add add() method with ID generation
- [x] Add update() method
- [x] Add delete() method
- [x] Add export() method
- [x] Add import() method
- [ ] Write unit tests for all methods (deferred - will test via UI)
- [ ] Test with empty storage (deferred - will test via UI)
- [ ] Test with existing data (deferred - will test via UI)
- [ ] Test error handling (deferred - will test via UI)

### Phase 2: Sync Service
- [ ] Implement SyncService class
- [ ] Add syncToCloud() method
- [ ] Add syncFromCloud() method
- [ ] Add conflict detection
- [ ] Add conflict resolution
- [ ] Add sync status tracking
- [ ] Write integration tests
- [ ] Test offline behavior
- [ ] Test authentication errors

### Phase 3: UI Integration
- [x] Replace eventsStorage with localStorageService in all components
- [x] Update Events screen
- [x] Update Event Detail screen
- [x] Update Create Event screen
- [x] Update Edit Event screen
- [ ] Add sync status UI (deferred - local-only for now)
- [ ] Add manual sync button (deferred - local-only for now)
- [ ] Test all CRUD operations (ready for user testing)

### Phase 4: Migration & Testing
- [ ] Create data migration script
- [ ] Run migration on app launch
- [ ] Complete manual testing checklist
- [ ] Verify data persists across restarts
- [ ] Verify sync works correctly
- [ ] Save final checkpoint

## Export Backup Bug (Critical)
- [x] Replace deprecated writeAsStringAsync with legacy API
- [ ] Test export creates valid JSON file (ready for user testing)
- [ ] Test import restores data correctly (ready for user testing)

## Import Backup Bug (Critical)
- [x] Investigate why import fails with valid backup file (found: confirm() not available in RN)
- [x] Add detailed error logging to import function
- [x] Fix import to properly restore events to local storage (replaced confirm with Alert.alert)
- [ ] Test import with user's backup file (ready for user testing)

## Contact Selection Bug (Critical)
- [x] Investigate why contacts don't appear after tapping Load Contacts (search filter issue)
- [x] Add debug logging to handlePickContacts function
- [x] Add total contacts count display
- [x] Add clear search button
- [x] Add "no matches" message when search returns empty
- [x] Fix contact search to support partial matching like iPhone ("Peter tho" should find "Peter Thorpe")
- [x] Make search case-insensitive
- [x] Fix participant edit screen to hide calendar/availability UI for fixed events (should only show RSVP + contact editing)
- [ ] Test selecting contact and verify participant is added (ready for user testing)
- [ ] Verify contact data (name, phone, email) is populated correctly (ready for user testing)

## Cloud Sync Implementation

- [x] Create sync-service.ts with offline-first architecture
- [x] Add auto-sync on app launch
- [x] Add manual sync button in events screen
- [x] Add auto-sync after creating event
- [ ] Add auto-sync after editing event
- [ ] Add auto-sync after editing participant
- [x] Debug TRPCClientError when syncing to cloud (participant ID conflicts)
- [x] Quick fix: Generate new participant IDs when copying from templates (already working)
- [x] Improve sync error handling and logging
- [ ] CRITICAL: Fix sync creating duplicate events instead of merging
- [ ] Disable auto-sync temporarily
- [ ] Clean up duplicate AI Guys events
- [ ] Fix syncFromCloud to check event IDs before adding
- [ ] Test sync with AI Guys and Guru Breakfast events
- [ ] Test multi-user collaboration (same event on multiple devices)
- [ ] Test cross-device sync (create on phone, view on another phone)

## Future: Contacts Architecture (Option 1)
- [ ] Design Contacts table schema
- [ ] Add database migration for Contacts table
- [ ] Update participant selection to use shared contacts
- [ ] Migrate existing participants to contacts
- [ ] Update sync logic for contacts

## UI Bugs

- [ ] Fix keyboard covering email/notes fields in participant edit screen (requires custom dev build or modal UI)
- [ ] Add visual indicators on event cards showing meeting type (Virtual/In-Person) and event type (Fixed/Flexible)

## Admin Screen and Event History Issues

- [x] Fix Admin Dashboard title truncation (showing "Admin Dashboa..." instead of full title)
- [ ] Clean up duplicate Guru Breakfast entries in Event History (5 duplicates with 0 people)
- [ ] Verify Response Rate calculation is accurate

## Event History Cleanup

- [ ] Add "Clear All History" button to Saves screen to delete all snapshots at once
- [ ] Fix desktop sync showing 3 participants instead of 6 for AI Guys event

## Cloud Sync Bug - Database Schema Mismatch

- [x] Fix participant insert query failing with "default, default" values for phone and email fields
- [x] Investigate database schema vs cloud storage adapter mismatch
- [x] Ensure phone and email fields are properly handled in participant inserts
- [x] Test sync after fix with AI Guys event (6 participants)


## Sync Duplication Bug - CRITICAL

- [x] Fix sync creating duplicate events instead of merging existing ones
- [x] iPhone now has 3 AI Guys events + 3 Guru Breakfast events (should be 1 each)
- [x] Desktop has 2 AI Guys events + 2 Guru Breakfast events (should be 1 each)
- [x] Sync logic should check if event already exists in cloud before creating new one
- [x] Add database cleanup tool to remove duplicate events
- [ ] Test sync doesn't create duplicates on subsequent syncs


## Sync Still Creating Duplicates After Fix

- [x] iPhone downloaded 4 events (2 AI Guys + 2 Guru Breakfast) instead of 2 clean events
- [x] Check if cloud database still has duplicates after cleanup script
- [x] Verify cleanup script actually deleted the duplicates
- [x] Check if sync is re-creating duplicates during download
- [x] Fixed tRPC participants.create to properly handle undefined optional fields
- [x] Removed undefined fields from participant data before database insert
- [ ] Test sync again after fixing root cause


## Sync Flow Creating Duplicates - CRITICAL

- [ ] fullSync() uploads local first, then downloads cloud, causing duplicates
- [ ] When user deletes all events and syncs, empty local state creates new events
- [ ] Need to redesign sync to be truly bidirectional merge, not sequential upload-then-download
- [ ] Sync should compare timestamps and only upload newer items
- [ ] Download should merge, not replace (already fixed)
- [ ] Upload should check if item exists in cloud before creating


## Download Merge Creating Duplicates - CRITICAL

- [ ] Sync reports "downloaded 2" but user sees 4 events
- [ ] Download merge logic is adding events twice instead of merging by ID
- [ ] Need to check if merge is being called multiple times
- [ ] Or if merge Map logic has a bug
- [ ] Verify AsyncStorage.setItem is being called correctly


## Participant Insert SQL Error Still Happening

- [ ] Server restart didn't apply tRPC fix - still seeing `default, default` in SQL
- [ ] Need to verify server is actually running new code
- [ ] Check if Drizzle ORM is automatically adding timestamp fields
- [ ] May need to modify db.createParticipant() instead of tRPC layer
- [ ] Add logging to verify which code path is executing


## Local Storage Not Syncing with UI State

- [ ] Deleting events in UI doesn't delete from AsyncStorage
- [ ] Events reappear after logout/login
- [ ] Need to check deleteEvent function in local storage
- [ ] UI state and persistent storage are out of sync


## Reset Button for Clean Slate

- [x] Create "Reset All Data" button in Admin tab
- [x] Clear all local AsyncStorage (events, snapshots, templates)
- [x] Delete all cloud data for current user
- [x] Show confirmation dialog before reset
- [x] Provide success feedback after reset

## Automatic Background Sync Redesign

- [x] Remove "Sync Now" button (bad UX pattern)
- [x] Auto-sync on every create/update/delete operation
- [x] Auto-sync on app open/resume
- [x] Auto-sync on network reconnect
- [x] Queue offline changes for later sync
- [x] Show sync status indicator (syncing/synced/offline)
- [x] Handle conflicts with last-write-wins strategy
- [x] Add retry logic for failed syncs
- [ ] Test automatic sync end-to-end with fresh data


## Participant Changes Not Persisting - CRITICAL

- [x] Participant added in event detail screen disappears when navigating back
- [x] Event date/time changes are saved correctly
- [x] Only participant data is being lost
- [x] Event detail screen now using auto-sync for all updates
- [x] Participant changes verified syncing to cloud database
- [x] Navigation preserves all changes correctly


## Add Participant from Contacts Not Working - CRITICAL

- [x] User searches contacts and finds their record
- [x] User presses "Add" button
- [x] Participant is not saved to the event
- [x] Fixed: add-participant screen now using auto-sync
- [x] Participant data being passed correctly
- [x] Modal closes after save completes


## Participant Disappears After RSVP Change - CRITICAL

- [x] Participant is added from contacts successfully
- [x] User changes RSVP status (e.g., to "attending")
- [x] Participant no longer disappears from the list
- [x] Fixed: edit-availability screen now using auto-sync
- [x] Participant data persists correctly
- [x] No race condition - sync handles updates atomically


## Expo Go Connection Issue

- [x] App stuck on "Opening project" spinner
- [x] Won't load after forced logout
- [x] Dev server was timing out
- [x] Fixed: restarted dev server
- [x] App loads successfully after restart
- [x] All data persisted correctly through restart

## Sync System Fix (Critical - Completed)

- [x] Implement automatic background sync that pushes all local changes to cloud
- [x] Fix pull sync to prevent duplicate events during merge
- [x] Add proper conflict resolution (last-write-wins with timestamps)
- [x] Cloud is now source of truth - pull sync deletes local events not in cloud
- [x] Test cross-device sync thoroughly (iPhone, iPad, Desktop)

## Event Creation Bug (Fixed)

- [x] Fix navigation to event-detail hanging after creating event
- [x] Event saves successfully locally but navigation times out
- [x] Make cloud push non-blocking so navigation happens immediately
- [x] Use addWithId() instead of add() to properly save full Event object
- [x] Add retry logic to event-detail to handle AsyncStorage write delays

## Add Participant Bug (Fixed)

- [x] Fix participant not being added after selection on flexible events
- [x] Debug add-participant screen flow
- [x] Participant addition working correctly

## Sync System Fixed (Was Critical)

- [x] Fix availability dates disappearing after being marked
- [x] Removed loadData() call that caused race condition
- [x] Implemented immediate cloud push with lock mechanism
- [x] Disabled automatic periodic sync (was causing data loss)
- [x] Changes now persist correctly
- [ ] Future: Re-implement smart periodic sync with proper conflict resolution

## Event Year Editing (Already Exists)

- [x] Year picker exists in edit-event screen
- [x] Shows current year + next 4 years
- [x] User can change year after creation

## Admin Dashboard UI Bug (Current)

- [x] Fix admin dashboard title "Admin Dashboard" getting cut off by iPhone notch (increased padding to 60px + insets)
- [x] Fix stat numbers (5, 5, 11, 63%) being partially cut off in cards (reduced font size from 3xl to xl)

## Venue Address and Directions Feature (Current)

- [x] Add venueAddress field to Event data model
- [x] Implement Google Maps Places Autocomplete for venue address search
- [x] Add address input field to edit-meeting-details screen
- [x] Add "Get Directions" button to event detail screen
- [x] Open address in native maps app (Google Maps/Apple Maps)
- [x] Display address in Meeting Details section for all participants

## Venue Search Redesign (Current)

- [x] Move Google Places autocomplete to Venue Name field
- [x] Auto-fill address when user selects a place from autocomplete
- [x] Make address field a simple editable text input (no autocomplete)
- [x] Allow manual address entry if user doesn't use autocomplete

## Venue Autocomplete UX Fixes (Current)

- [x] Fix text visibility in venue name autocomplete (removed conflicting value prop, added proper color)
- [x] Fix keyboard covering venue name field (added KeyboardAvoidingView wrapper)

## Onboarding Tutorial (Current)

- [x] Create 3-screen onboarding flow for first-time users
- [x] Screen 1: Explain date polling feature
- [x] Screen 2: Explain venue search and RSVP tracking
- [x] Screen 3: Explain local vs cloud sync options
- [x] Add first-launch detection using AsyncStorage
- [x] Show onboarding on first app launch only
- [x] Allow users to skip onboarding

## Event Detail Screen Redesign (Current)

- [x] Show all meeting details by default (venue, address, contact, meeting link)
- [x] Remove need to tap edit pencil just to view information (Meeting Details section now always visible)
- [x] Add share button to event detail screen (header, quick share)
- [x] Add forward button to event detail screen (header, includes venue/meeting details)
- [x] Keep edit pencil for actual editing (in Meeting Details section)

## Meeting Details Empty State (Current)

- [ ] Add helpful message when Meeting Details section is empty
- [ ] Show "Tap pencil to add meeting details" prompt
- [ ] Make it clear that users should add venue, team leader, etc.

## Venue Data Not Persisting (Current Bug)

- [x] Venue information (name and address) not saving when user edits meeting details
- [x] User adds venue via Google Places autocomplete but data disappears after save
- [x] Fixed: Now using details.formatted_address from Google Places API
- [x] Fixed: Using structured_formatting.main_text for clean venue name

## CRITICAL: Meeting Details Not Persisting to Storage

- [x] Meeting details (venue, contact, phone) save initially but disappear on reload
- [x] Data shows up immediately after save but is lost when navigating away and back
- [x] Issue affects: venueName, venueAddress, venueContact, venuePhone, teamLeader, teamLeaderPhone
- [x] Fixed: Changed from eventsLocalStorage.update to useAutoSync().updateEvent
- [x] Fixed: Now using proper auto-sync flow for persistence and cloud sync

## Get Directions Button Not Showing (Web)

- [x] Get Directions button not visible under venue address in web preview
- [x] Issue was different data storage between iPhone and web (expected behavior)
- [x] User needs to log in on both devices to see synced data

## Login Status Indicator (Current)

- [x] Add persistent visual indicator showing login status
- [x] Show user name/email or profile icon when logged in (initials in circle)
- [x] Show clear "Login" indicator when logged out
- [x] Make it visible on all screens (top-right of every tab)
- [x] Created profile screen showing account info and sync status

## Android APK Build for Testing (Current)

- [ ] Build Android APK for direct installation on Android devices
- [ ] Provide download link for Mike and other Android testers
- [ ] Create installation instructions for non-technical users
- [ ] Test APK installation and functionality on Android device

## Event Import via Deep Link (CRITICAL - Current)

- [x] Add deep link support for event sharing
- [x] When user shares event, include special link in SMS/WhatsApp message
- [x] Recipient taps link → Opens GatherSync → Event automatically imported
- [x] Show confirmation dialog when importing shared event
- [x] Allow recipient to RSVP immediately after import
- [x] Simplify share message - clean format with "Tap to join" call-to-action

## Web-Based Event Sharing (Critical - Current)

- [x] Create public event view page accessible via web browser
- [x] Allow recipients to mark availability directly on web page (no app required)
- [x] Show "Download App" button on web page with app store links
- [x] Web page saves availability to cloud database
- [x] Web page shows event name, date/time, venue, organizer
- [x] Web page has interactive calendar for marking availability (flexible events)
- [x] Web page has RSVP buttons (fixed events)
- [x] Web page works on mobile and desktop browsers
- [ ] Replace deep link with clean HTTPS web link in share messages
- [ ] Configure app for web deployment (Expo web build)
- [ ] Test public event page on mobile browsers (Safari, Chrome)
- [ ] Test public event page on desktop browsers
- [ ] Purchase gathersync.com domain
- [ ] Configure custom domain with Manus deployment
- [ ] Update share message format to use gathersync.com URLs

## Professional Web Event Page (Current - Priority)

- [x] Create REST API for public event access (no authentication required)
- [x] Public event page loads and displays event details correctly
- [x] RSVP functionality works and saves responses to database
- [x] Redesign public event page with professional branding and styling
- [x] Add GatherSync logo and branded header to public page
- [x] Improve typography, spacing, and visual hierarchy
- [x] Optimize mobile design for phone screens (primary use case)
- [x] Add better instructions and user guidance copy
- [x] Make design consistent with app branding
- [x] Replace deep link with clean HTTPS web link in share messages
- [x] Purchase gathersync.app domain
- [ ] Test full flow: share event → receive link → RSVP → see response in app
- [ ] Configure custom domain with Manus deployment after publish
- [ ] Update share message URLs to use gathersync.app after domain configuration

## Smart Link and Import Features (Current - Priority)

- [x] Add name parameter support to public event URL (?name=Lynnette+Glory)
- [x] Pre-fill name field when name parameter is present
- [x] Check if participant with that name already exists in event
- [x] Load existing participant's availability when name matches
- [x] Allow existing participants to update their response
- [x] Add "Import to App" button on public event page
- [x] Generate deep link for importing event into GatherSync app
- [x] Handle deep link in app to import event with all participants (already exists)
- [x] Add "Share with Participants" feature that sends personalized links
- [x] Generate personalized URLs with participant names for each person
- [ ] Test smart link with Lynnette (existing participant)
- [ ] Test import with Gabbi (new recipient)
- [ ] Test "Share with Participants" sends correct personalized messages

## Marketing Website Deployment (Current - Priority)

- [ ] Copy marketing website files into mobile app project
- [ ] Set up web routing for marketing pages (landing, pricing, thank-you)
- [ ] Configure root URL to show marketing landing page
- [ ] Ensure app routes don't conflict with marketing routes
- [ ] Copy lifestyle event photos to app assets
- [ ] Test marketing pages in Expo web build
- [ ] Test navigation between marketing site and app
- [ ] Create checkpoint with unified deployment
- [ ] Provide DNS configuration instructions for gathersync.app
- [ ] Document how to update marketing content


## Subscription System (In Progress)

### Phase 1: Database & Core Logic ✅
- [x] Add subscription fields to users table (tier, status, Stripe IDs, event counter)
- [x] Create subscription utility functions
- [x] Add subscription limits configuration (Free: 5 events/month, Pro: unlimited)
- [x] Write comprehensive unit tests (22 tests passing)

### Phase 2: UI & Limit Enforcement ✅
- [x] Add subscription section to Profile screen
- [x] Show current tier, pricing, and usage
- [x] Create Upgrade screen with plan comparison
- [x] Add "Upgrade to Pro" button for Free users
- [x] Enforce event creation limits (block Free users at 5 events/month)
- [x] Show upgrade prompt when limit reached

### Phase 3: Stripe Payment Integration
- [ ] Set up Stripe account
- [ ] Add Stripe SDK to mobile app
- [ ] Create Stripe checkout session endpoint
- [ ] Build payment screen with Stripe Elements
- [ ] Handle successful payment
- [ ] Handle payment failures
- [ ] Test payment flow end-to-end

### Phase 4: Webhooks & Subscription Management
- [ ] Create Stripe webhook endpoint
- [ ] Handle subscription.created event
- [ ] Handle subscription.updated event
- [ ] Handle subscription.deleted event
- [ ] Handle payment_intent.succeeded event
- [ ] Handle payment_intent.failed event
- [ ] Update user subscription status from webhooks
- [ ] Add subscription cancellation flow
- [ ] Add subscription reactivation flow
- [ ] Show receipt/invoice history

### Phase 5: Admin Dashboard
- [ ] Create admin view for all subscribers
- [ ] Add revenue analytics
- [ ] Show subscription status overview
- [ ] Add customer management tools
- [ ] Export subscriber data

### Future Enhancements
- [ ] Add 7-day free trial for Pro tier
- [ ] Implement promo codes / discount system
- [ ] Add annual billing option (save 20%)
- [ ] Create team/organization plans
- [ ] Add usage analytics for users
- [ ] Implement monthly counter reset automation
- [ ] Add email notifications for subscription events


## Critical Bugs (Reported by User)

- [x] Fix subscription limit check - now counts actual events created this month instead of database counter
- [x] Verified no Australia-specific location assumptions exist (phone format, venue fields are already global)
- [x] Venue/location fields are free text and work for any country
- [ ] Consider adding location/timezone context to events for international use (future enhancement)


## Promotional System (In Progress)

### Phase 1: Database Schema
- [x] Add trial tracking fields (trialStartDate, trialEndDate, trialUsed)
- [x] Add promo code fields (appliedPromoCode, promoExpiry)
- [x] Add admin override field (isLifetimePro, grantedBy, grantedAt)
- [x] Add subscription source tracking (trial, promo, stripe, admin)

### Phase 2: Admin Panel
- [x] Create admin API endpoints (backend ready)
- [x] Create SQL commands guide for direct database management
- [x] Document how to grant lifetime Pro access
- [x] Document how to view all subscribers
- [x] Document subscription analytics queries
- [ ] (Optional) Build web UI for admin panel (deferred - SQL commands sufficient for now)

### Phase 3: Free Trial System
- [x] Create trial API endpoints (startTrial, getTrialStatus, checkExpiredTrials)
- [x] Add "Start Free Trial" button in Profile screen
- [x] Show trial countdown in Profile screen (e.g., "Pro Trial (12 days remaining)")
- [x] Add trial expiration check on app launch
- [x] Auto-downgrade to Free when trial expires
- [x] Trial success notification with confetti
- [ ] (Optional) Auto-grant trial to new users on first login

### Phase 4: Promo Codes
- [ ] Create promo code generation system
- [ ] Add promo code redemption screen
- [ ] Validate promo codes
- [ ] Track promo code usage
- [ ] Set expiry dates for promo codes


## Bugs to Fix

- [x] User subscription data not refreshing from database after admin SQL updates
- [x] Added refresh button in Profile header to reload user data
- [x] Added subscription fields to API response (buildUserResponse)

- [x] Mobile refresh() now fetches from API instead of cached local storage
- [x] Mobile fetchUser calls /api/auth/me to get fresh subscription data

- [x] Fixed Auth.User type to include subscription fields
- [x] Fixed use-auth hook to map subscription fields from API response
- [x] Refresh button now properly updates subscription status from database


## Critical Bug - Participant Duplication

- [x] Added duplicate check before adding participants (checks email and name)
- [x] App now shows alert if trying to add duplicate participant
- [x] Prevents same person from being added twice to an event
- [ ] User needs to manually delete existing duplicate Lynnette Glory entry


## Critical Bug - Sync Conflicts

- [ ] Deleted participants reappear after leaving and returning to event
- [ ] Deleted events (Event 7) reappear after sync
- [ ] Cloud sync is overwriting local deletions
- [ ] Need to fix sync merge logic to respect local changes
- [ ] May need to implement proper conflict resolution (last-write-wins or tombstones)

## Subscription & Payment System (In Progress)

### Backend Implementation
- [x] Install Stripe SDK in server
- [x] Add Stripe API keys to environment variables (temporary hardcoded)
- [x] Create Stripe customer on user signup
- [x] Add subscription creation endpoint (tRPC)
- [x] Add webhook handler for Stripe events (payment success, cancellation)
- [x] Add subscription status check endpoint
- [x] Add cancel subscription endpoint
- [x] Add subscription portal link generation

### Frontend Implementation
- [x] Create pricing/plans screen showing Free vs Pro
- [x] Create "Go Pro" upgrade button in Events screen when at limit
- [x] Integrate Stripe Checkout for payment
- [x] Show subscription status in Profile screen
- [x] Add "View Subscription" button for Pro users
- [x] Update event limit enforcement for Pro users (unlimited)
- [x] Add event counter in Events screen header (X/5 events)
- [x] Show features comparison (Free: 5 events, Pro: unlimited)
- [x] Create subscription success screen

### Testing
- [ ] Test successful payment flow end-to-end
- [ ] Test subscription cancellation
- [ ] Test webhook handling (payment success)
- [ ] Test webhook handling (subscription cancelled)
- [ ] Test event limit updates after upgrade
- [ ] Test with Stripe test cards

## Bug Fixes (Current)
- [x] Profile screen routing to old upgrade.tsx instead of new pricing.tsx
- [x] Old upgrade screen shows $3.99 instead of $9.99
- [ ] Stripe redirect after payment fails on mobile ("problem running requested app")
- [ ] Need to use proper deep link URL for Stripe success/cancel redirects

## Critical Bugs
- [x] Login screen shows "Login functionality to be implemented" after logout (login banner on Events screen works)
- [x] Pro subscription not applying after Stripe payment (fixed with isLifetimePro)
- [ ] Webhook not properly updating subscription tier from 'free' to 'pro' after payment (webhook code is correct, needs Stripe dashboard configuration)
- [x] Mobile redirect after Stripe payment fixed with proper deep link scheme
- [x] Subscription success screen now refreshes user data automatically

## New Pricing Structure Implementation
- [ ] Create Stripe product for Lite tier ($4.99/month, $49/year)
- [ ] Create Stripe product for Pro tier ($7.99/month, $79/year)
- [ ] Update pricing screen to show 3 tiers (Free/Lite/Pro)
- [ ] Add monthly/annual billing toggle
- [ ] Update event limit logic for Lite (50 events max)
- [ ] Update subscription tier enum to include 'lite'
- [ ] Test Lite tier checkout flow
- [ ] Test Pro tier checkout flow
- [ ] Test annual billing

## New Pricing Structure Implementation
- [x] Create Stripe Lite product ($4.99/month, 50 events)
- [x] Create Stripe Pro product ($7.99/month, unlimited)
- [x] Add annual pricing for both tiers (2 months free)
- [x] Update pricing screen to show 3 tiers (Free/Lite/Pro)
- [x] Add monthly/annual billing toggle
- [x] Update event limit logic for Lite tier (50 events)
- [x] Update event counter display for Lite users
- [ ] Fix TypeScript errors (type definitions not refreshed)
- [ ] Test checkout flow for all tiers

## Stable Version Fix - 281225-STABLE-v2

- [x] Fix Profile page login button (add working OAuth redirect)

## Rollback to Working Version - 281225-07

- [x] Rolled back to checkpoint 850b72f (stable production version)
- [x] This was the version working before OAuth login attempts
- [ ] Only remaining issue: Hide "9/5 events" counter for Lifetime Pro users
- [ ] DO NOT attempt to "fix" OAuth login - it was already working

- [x] Login still not working after rollback
- [x] Check Events screen login button implementation
- [x] Fix login to work on mobile - changed router.push() to WebBrowser.openBrowserAsync()

## OAuth Callback Spinning Issue - 281225-08

- [x] Continue to GatherSync button keeps spinning after OAuth
- [x] WebBrowser.openBrowserAsync() doesn't handle callback redirect properly
- [x] Check OAuth callback redirect URL configuration
- [x] Fix redirect to use API server callback for both web and mobile
- [x] Changed getLoginUrl() to always use API server callback endpoint

## Subscription Display Issues - 281225-09

- [x] User logged in successfully but shows as Free account
- [x] "9/5 events" counter showing for Lifetime Pro user
- [x] Check database subscription status
- [x] Hide event counter for Lifetime Pro users (already in code, line 534)
- [x] Updated Peter Scarfo account to Lifetime Pro in database
- [ ] User needs to logout and login again to refresh subscription data


## Launch Preparation - Web Version Priority - 281225-10

### Web App (app.gathersync.app) Fixes
- [ ] Fix subscription display on web - showing Free instead of Lifetime Pro
- [ ] Verify all web app features working correctly
- [ ] Test sign up flow for Free/Lite/Pro plans
- [ ] Ensure payment integration works on web

### Marketing Site (gathersync.app) Updates
- [ ] Change Android download button to "Under Development - Coming Soon"
- [ ] Change iOS download button to "Under Development - Coming Soon"
- [ ] Add prominent link/button to web app (app.gathersync.app)
- [ ] Make it clear web version is available now

### Testing Before Launch
- [ ] Test complete user journey from marketing site to web app
- [ ] Verify subscription tiers display correctly
- [ ] Test payment flow end-to-end
- [ ] Confirm Lifetime Pro status shows correctly on web

**Target: Launch within next day or so**


## Web App Subscription Display Fix

- [x] Web app shows Free account instead of Lifetime Pro
- [x] Web app missing subscription fields in user object
- [x] Fix use-auth.ts to include subscription data for web platform
- [x] Add logging to buildUserResponse to debug subscription data
- [ ] Test web app and check console logs for subscription values
- [ ] Verify event counter is hidden on web app after fix


## Netlify Web App Deployment

- [x] Export web build with subscription fix
- [x] Create zip file for Netlify deployment (gathersync-web-20251227-214152.zip)
- [ ] Upload zip to Netlify to update app.gathersync.app
- [ ] Test web app shows Lifetime Pro after deployment


## Event Card Grid Layout Fix

- [x] Fix event card grid to display consistent columns (not 3-3-4 jagged layout)
- [x] Ensure all event cards have same width (maxWidth: 400px on web)
- [x] Added 3-column grid layout for web using FlatList numColumns
- [x] Added flexWrap and proper spacing for web grid
- [x] Export as gathersync-281225-05.zip (1.6 MB)


## Desktop Sidebar Navigation (Web Only)

- [x] Create DesktopLayout component with left sidebar
- [x] Add GatherSync logo/branding to sidebar
- [x] Add navigation menu (Events, Admin, Saves, Profile)
- [x] Make sidebar responsive (desktop only, hidden on mobile)
- [x] Apply DesktopLayout to Events page
- [ ] Optionally apply to Profile page based on user feedback
- [ ] Constrain content width for professional appearance


## Sidebar and Navigation Fixes

- [x] Update sidebar logo to use actual GatherSync app icon (not generic calendar)
- [x] Apply DesktopLayout to Profile page
- [x] Apply DesktopLayout to Admin page
- [x] Apply DesktopLayout to Saves page
- [x] Apply DesktopLayout to Templates page
- [ ] Apply DesktopLayout to other modal pages (if needed)
- [x] Fix logout button functionality (web-compatible confirm dialog)
- [x] Fix login redirect to go to app.gathersync.app/events (already correct)
- [x] Update marketing site Android button to show "Under Development - Coming Soon"
- [x] Update marketing site iOS button to show "Under Development - Coming Soon"


## Marketing Site Fixes

- [x] Fix app.gathersync.app link to point to actual web app (not redirect to marketing site)
- [x] Restore Get in Touch form to send messages to peter.scarfo@gmail.com with all form data

## Event Detail Page Fixes

- [x] Add DesktopLayout sidebar to Event Detail page
- [x] Add copyright footer to Event Detail page (included in DesktopLayout)


## OAuth Login Redirect Issue

- [x] Fix OAuth redirect URL to point to app.gathersync.app instead of backend API server
- [x] Update OAuth callback to exchange code directly with Manus OAuth server for production
- [x] Ensure after login user lands on app.gathersync.app/events (not marketing site)


## Backend Deployment to Render.com (Critical)

- [x] Create render.yaml configuration file
- [x] Set up build and start scripts for production
- [x] Document required environment variables
- [x] Create deployment instructions for Render.com (RENDER_DEPLOYMENT.md)
- [x] Update frontend OAuth config to use production API URL via EXPO_PUBLIC_API_BASE_URL
- [x] Revert OAuth to use API server callback (works with Render)
- [x] Create complete deployment guide (DEPLOYMENT_GUIDE.md)
- [ ] User needs to deploy backend to Render following DEPLOYMENT_GUIDE.md
- [ ] User needs to set EXPO_PUBLIC_API_BASE_URL and rebuild frontend
- [ ] User needs to test OAuth flow with production setup

## Production Deployment Issues

- [x] Fix blank edit-meeting-details screen in production web app (moved marketing site files out of /public to prevent conflict)
