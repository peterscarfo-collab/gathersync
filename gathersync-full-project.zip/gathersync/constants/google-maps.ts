/**
 * Google Maps API Configuration
 */

export const GOOGLE_PLACES_API_KEY = 'AIzaSyDXVvmyjMHkAbWgxy__tIhNhtIVxkv0EFU';
