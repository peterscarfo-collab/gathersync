ALTER TABLE `events` ADD `deletedAt` timestamp;--> statement-breakpoint
ALTER TABLE `participants` ADD `deletedAt` timestamp;