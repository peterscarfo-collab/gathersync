import { WEB_BASE_URL } from '@/constants/urls';

function getBaseOrigin(): string {
  return WEB_BASE_URL.replace(/\/+$/, '');
}

export function buildPublicEventUrl(eventId: string): string {
  try {
    const url = new URL('/public-event', `${getBaseOrigin()}/`);
    url.searchParams.set('eventId', eventId);
    return url.toString();
  } catch {
    return `${getBaseOrigin()}/public-event?eventId=${encodeURIComponent(eventId)}`;
  }
}

export function buildPublicEventParticipantUrl(eventId: string, participantName: string): string {
  try {
    const url = new URL('/public-event', `${getBaseOrigin()}/`);
    url.searchParams.set('eventId', eventId);
    url.searchParams.set('name', participantName);
    return url.toString();
  } catch {
    return `${getBaseOrigin()}/public-event?eventId=${encodeURIComponent(eventId)}&name=${encodeURIComponent(participantName)}`;
  }
}
