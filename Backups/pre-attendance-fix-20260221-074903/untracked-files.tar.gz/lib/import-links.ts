import AsyncStorage from '@react-native-async-storage/async-storage';

const IMPORT_LINKS_KEY = '@gathersync_import_links';

type ImportLinksMap = Record<string, string>;

async function readLinks(): Promise<ImportLinksMap> {
  try {
    const raw = await AsyncStorage.getItem(IMPORT_LINKS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object') return {};
    return parsed as ImportLinksMap;
  } catch (error) {
    console.warn('[ImportLinks] Failed to read links:', error);
    return {};
  }
}

async function writeLinks(links: ImportLinksMap): Promise<void> {
  try {
    await AsyncStorage.setItem(IMPORT_LINKS_KEY, JSON.stringify(links));
  } catch (error) {
    console.warn('[ImportLinks] Failed to write links:', error);
  }
}

export async function setImportedSourceEventId(importedEventId: string, sourceEventId: string): Promise<void> {
  if (!importedEventId || !sourceEventId) return;
  const links = await readLinks();
  links[importedEventId] = sourceEventId;
  await writeLinks(links);
}

export async function getImportedSourceEventId(importedEventId: string): Promise<string | null> {
  if (!importedEventId) return null;
  const links = await readLinks();
  return links[importedEventId] || null;
}

export async function removeImportedSourceEventId(importedEventId: string): Promise<void> {
  if (!importedEventId) return;
  const links = await readLinks();
  if (!(importedEventId in links)) return;
  delete links[importedEventId];
  await writeLinks(links);
}
