# GatherSync Beta Daily Ops Checklist

Use this runbook during active tester waves to keep execution consistent.

## Daily Cadence (Recommended)

- 9:00 AM: Collect incoming feedback
- 10:00 AM: Triage and severity tagging
- 11:00 AM: Prioritize fixes
- 2:00 PM: Validate fixes
- 4:00 PM: Send tester update

Adjust times to your team schedule.

## Start-of-Day Checklist

- [ ] Review all reports submitted since last update
- [ ] Confirm report completeness (environment, steps, expected/actual)
- [ ] Request missing info from testers where needed
- [ ] Update tracker status for each issue

## Triage Checklist

For every new item:

- [ ] Assign severity: `critical`, `major`, `minor`
- [ ] Assign area: `onboarding`, `events`, `participants`, `sharing`, `public-page`, `ui`, `performance`, `other`
- [ ] Confirm reproducible yes/no
- [ ] Assign owner
- [ ] Set target fix day

## Prioritization Rules

1. `critical` first (same day)
2. `major` next (same or next day)
3. `minor` bundled for polish pass

Do not promote minor items above blocking flow issues.

## Fix and Verify Checklist

- [ ] Implement highest-priority fixes
- [ ] Re-test exact reproduction steps
- [ ] Run quick regression on related flow
- [ ] Mark issue status:
  - `new`
  - `in progress`
  - `fixed - needs verification`
  - `verified`
  - `closed`

## Tester Comms Checklist (Daily Update)

Send one daily message with:

- [ ] What was fixed today
- [ ] What is in progress
- [ ] Known blockers/workarounds
- [ ] What to test next
- [ ] Next update time

Keep updates concise and action-focused.

## Mid-Wave Health Checks

- [ ] At least one non-technical tester completed end-to-end organizer flow
- [ ] At least one tester completed participant public response flow
- [ ] No open `critical` issue older than 24 hours
- [ ] Open `major` issues are tracked with workaround notes

## End-of-Wave Exit Checklist

- [ ] No open `critical` issues
- [ ] Open `major` issues are within acceptable threshold
- [ ] Core flows validated:
  - [ ] Login
  - [ ] Create event
  - [ ] Add participants
  - [ ] Share link
  - [ ] Submit response
  - [ ] Organizer view updates
  - [ ] Archive/finalize
- [ ] Stakeholder sign-off captured
- [ ] Ready to start next wave or release prep

## Optional Daily Status Template

```text
Beta Daily Update - [DATE]

Completed today:
- ...

In progress:
- ...

Known issues/workarounds:
- ...

Tester asks for tomorrow:
- ...

Next update:
- [TIME]
```
