# GatherSync Prebeta Prep Checklist

Use this checklist to prepare and run external prebeta safely.

## A) Preview Environment

- [ ] Deploy `marketing/rescued-site/` to Netlify preview URL
- [ ] Verify pages load:
  - [ ] `/`
  - [ ] `/coming-soon-app-store.html`
  - [ ] `/coming-soon-google-play.html`
  - [ ] `/privacy-policy.html`
  - [ ] `/terms-of-service.html`
- [ ] Optional: map `preview.gathersync.app` subdomain
- [ ] Optional: add password protection

## B) Content and Links

- [ ] Confirm `Open Web App` button behavior is intentional for prebeta
- [ ] Confirm contact email is `hello@gathersync.app`
- [ ] Confirm offer copy: **12 months Pro free** on both coming-soon pages
- [ ] Confirm legal links work from footer

## C) Tester Operations

- [ ] Fill Wave 1 testers (`T01`-`T05`) in `templates/TESTER_TRACKER.csv`
- [ ] Insert preview link into `templates/WAVE1_INVITE_READY.md`
- [ ] Send invites to Wave 1
- [ ] Collect bug reports using `templates/BUG_REPORT_TEMPLATE.md`
- [ ] Send daily updates using `templates/TESTER_UPDATE_TEMPLATE.md`

## D) Bug Triage

- [ ] Label each issue: `critical` / `major` / `minor`
- [ ] Fix all critical issues before Wave 2
- [ ] Re-test all fixed issues on preview
- [ ] Mark tracker status updates for each tester and issue batch

## E) Wave 2 and Sign-off

- [ ] Add Wave 2 testers (`T06`-`T10`)
- [ ] Re-run invites with latest preview link
- [ ] Confirm no critical open issues
- [ ] Confirm major issues are acceptable or fixed
- [ ] Record prebeta completion decision

## Go/No-Go Criteria

Proceed from prebeta when all are true:

- [ ] 0 critical open bugs
- [ ] Legal/contact links verified
- [ ] Core CTA flow works end-to-end
- [ ] Stakeholder sign-off captured

## Source Files

- `marketing/TESTER_PREVIEW_SETUP.md`
- `marketing/TEST_RUN_PLAN.md`
- `marketing/templates/TESTER_TRACKER.csv`
- `marketing/templates/WAVE1_INVITE_READY.md`
- `marketing/templates/BUG_REPORT_TEMPLATE.md`
