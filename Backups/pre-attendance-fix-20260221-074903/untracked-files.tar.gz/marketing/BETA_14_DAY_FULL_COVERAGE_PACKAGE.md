# GatherSync 14-Day Beta Test Package (Full Coverage + Full Understanding)

This package is designed so testers both:

1. Learn exactly what GatherSync is for and how to use it confidently, and
2. Test every critical workflow over a structured 14-day period.

Use this as the single source of truth for your beta cohort.

---

## Program Goals

- Validate all core organizer and participant flows in real-world usage.
- Catch critical and major bugs early, then re-test fixes for regression.
- Ensure testers understand product purpose, key value, and expected outcomes.
- Produce launch-quality qualitative and reproducible bug feedback.

---

## What Testers Should Understand by Day 14

By the end of this package, each tester should be able to clearly explain:

- What GatherSync does: coordinate events by collecting participant responses.
- Who it serves: organizers and participants with different roles and needs.
- Core event types: flexible availability events and fixed-date RSVP events.
- Primary lifecycle: create -> add participants -> share -> collect responses -> finalize/archive.
- Reliability expectations: saved state, update behavior, and repeatable workflows.

---

## Success Criteria (Program-Level)

Program is successful when:

- No open `critical` issues remain.
- No more than 2 accepted `major` issues remain with documented workaround.
- 90%+ testers complete all required day assignments.
- Each tester submits at least 2 actionable reports.
- Each core flow is tested by at least 3 different testers.

---

## Tester Cohort and Time Commitment

- Recommended cohort size: 8-12 testers.
- Time commitment: 20-35 minutes per day.
- Mix:
  - 60-70% non-technical everyday users
  - 20-30% detail-oriented process testers
  - 10-20% technical testers (browser/device variation + edge behavior)

---

## Environment Matrix (Assign Before Day 1)

Assign each tester one primary and one backup environment:

- Desktop Chrome (latest)
- Desktop Safari (latest)
- Optional: Desktop Firefox or Edge
- Mobile Safari (iOS)
- Mobile Chrome (Android, if available)

Track coverage in: `marketing/templates/TESTER_TRACKER.csv`

---

## Severity and Reporting Standard

Use existing template: `marketing/templates/BUG_REPORT_TEMPLATE.md`

Severity labels:

- `critical`: blocks core flow; cannot continue
- `major`: high-impact issue with workaround
- `minor`: cosmetic/low-impact issue

Required report fields:

- Device / OS / browser
- URL or screen name
- Steps to reproduce
- Expected vs actual
- Severity
- Screenshot or short clip when possible

---

## 14-Day Curriculum and Test Plan

Each day includes:

- **Learn**: what the tester should understand
- **Do**: concrete testing tasks
- **Submit**: required output to keep quality high

### Day 1 - Product Orientation + Access

Learn:

- Product purpose and organizer vs participant roles.
- Overall flow from event setup to final outcome.

Do:

1. Read `marketing/BETA_TESTER_GUIDE.md`.
2. Log in using email code flow.
3. Navigate key surfaces (events list, event detail, share/public page if available).

Submit:

- One short note: "What GatherSync does in one sentence."
- Any onboarding confusion points.

### Day 2 - Flexible Event Creation

Learn:

- Flexible events capture date availability before final scheduling.

Do:

1. Create one flexible event.
2. Fill all key fields (name, timeframe, meeting details).
3. Save, refresh, and confirm persistence.

Submit:

- Screenshot of saved event.
- Report any unclear form labels or validation behavior.

### Day 3 - Fixed Event Creation

Learn:

- Fixed events are RSVP-first with known date/time.

Do:

1. Create one fixed event.
2. Confirm date/time, details, and save behavior.
3. Verify event appears in list and detail views.

Submit:

- Compare flexible vs fixed UX clarity (2-3 bullets).

### Day 4 - Participant Management Fundamentals

Learn:

- Participant data quality drives response quality.

Do:

1. Add participants manually.
2. Add participants using a second method (contacts/groups/directory if enabled).
3. Try duplicate, edit, and remove flows.

Submit:

- One "easy" and one "friction" note from participant management.

### Day 5 - Share Flow and Public Link Reliability

Learn:

- Share is the bridge between organizer setup and participant action.

Do:

1. Generate/copy share link.
2. Open link in incognito or second browser profile.
3. Validate link opens reliably and can be reused.

Submit:

- Link flow pass/fail with notes on trust/clarity.

### Day 6 - Participant Response: First Submission

Learn:

- Participant-side form clarity determines completion rate.

Do:

1. Submit response on flexible event (availability selection).
2. Submit response on fixed event (attending/not attending).
3. Add optional note in at least one response.

Submit:

- Confirm success state language is clear.
- Report any mismatch between participant action and organizer display.

### Day 7 - Response Updates and Data Integrity

Learn:

- Real users change plans; updates must be frictionless and accurate.

Do:

1. Update a previous response.
2. Refresh during/after update flow.
3. Verify updated state appears correctly in organizer view.

Submit:

- Integrity check result: did latest response overwrite old state correctly?

### Day 8 - Organizer Review and Decision Confidence

Learn:

- Organizer must trust summaries/counts to make decisions.

Do:

1. Review participant list and statuses.
2. Check counts/summaries after multiple responses.
3. Confirm notes visibility and context usefulness.

Submit:

- Confidence score (1-5) for "I can make a scheduling decision from this data."
- Explain score in 2-3 bullets.

### Day 9 - Edit Event Details Midstream

Learn:

- Real planning is iterative; edits should not break participation.

Do:

1. Edit event details after responses exist.
2. Verify updated details everywhere they should appear.
3. Confirm old responses remain valid (unless intentionally changed by design).

Submit:

- Any side effects caused by edits.

### Day 10 - Completion Actions (Finalize / Archive / Unarchive)

Learn:

- Completion states are part of lifecycle, not an afterthought.

Do:

1. Finalize date when applicable.
2. Archive event.
3. Unarchive and confirm recoverability.

Submit:

- Pass/fail for lifecycle actions with one screenshot.

### Day 11 - Reliability and Recovery Stress Pass

Learn:

- Reliability includes handling imperfect user behavior.

Do:

1. Use back navigation during form actions.
2. Refresh during active flows.
3. Repeat key actions (copy/share/submit) more than once.

Submit:

- At least one edge-case observation (bug or "works as expected" evidence).

### Day 12 - Cross-Device / Cross-Browser Validation

Learn:

- Behavior consistency affects trust and adoption.

Do:

1. Repeat critical flow in alternate browser/device.
2. Compare key screens and interaction behavior.
3. Note responsive layout or input differences.

Submit:

- Compatibility notes for both environments.

### Day 13 - Regression Re-Test Day

Learn:

- Good testing includes verifying fixes, not only finding first issues.

Do:

1. Re-test all previously reported `critical` and `major` issues that were fixed.
2. Re-run core flow quickly:
   - create event
   - add participant
   - share
   - submit response
   - verify update

Submit:

- Regression verdict per issue: fixed / partially fixed / still broken.

### Day 14 - Final Assessment and Launch Readiness

Learn:

- Summarizing usability + reliability findings enables decision-making.

Do:

1. Complete final end-to-end run in your primary environment.
2. Submit final feedback packet.
3. Answer product understanding questions below.

Submit:

- Final report:
  - top 3 strengths
  - top 3 blockers/frictions
  - launch recommendation: ready / ready with conditions / not ready
- Product understanding answers:
  1. What core problem does GatherSync solve?
  2. What is the difference between flexible and fixed events?
  3. What is the minimum organizer flow from setup to decision?
  4. What one change would most improve clarity or trust?

---

## Daily Facilitator Rhythm (Internal Team)

Run this cadence each day:

1. Collect all tester updates by 10:00 AM.
2. Triage with severity labels by 11:00 AM.
3. Prioritize fixes: `critical` -> `major` -> `minor`.
4. Share daily update to testers (known issues + fixes to re-test).
5. Update tracker and coverage matrix.

Use:

- `marketing/BETA_DAILY_OPS_CHECKLIST.md`
- `marketing/templates/TESTER_UPDATE_TEMPLATE.md`

---

## Coverage Matrix (Must Be Green by Day 14)

Mark each as `Not Tested`, `In Progress`, or `Pass/Fail with issue link`.

- Login and access flow
- Flexible event creation
- Fixed event creation
- Participant add/edit/remove
- Duplicate handling
- Share link creation and reuse
- Public response submission
- Response update flow
- Organizer-side visibility and counts
- Notes/optional context handling
- Event detail editing post-response
- Finalize/archive/unarchive lifecycle
- Refresh/back-navigation reliability
- Cross-browser/device behavior
- Regression verification on fixed issues

---

## Deliverables Checklist

By end of program:

- [ ] Daily tester submissions for 14 days
- [ ] Updated `marketing/templates/TESTER_TRACKER.csv`
- [ ] Bug reports in standard format with severity
- [ ] Regression verification notes
- [ ] Final launch readiness summary

---

## Existing Supporting Assets (Use Together With This Package)

- Primary tester guide: `marketing/BETA_TESTER_GUIDE.md`
- Master packet: `marketing/BETA_TESTER_MASTER_PACKET.md`
- Test run plan: `marketing/TEST_RUN_PLAN.md`
- Bug report template: `marketing/templates/BUG_REPORT_TEMPLATE.md`
- Tester tracker: `marketing/templates/TESTER_TRACKER.csv`
- Tester updates template: `marketing/templates/TESTER_UPDATE_TEMPLATE.md`

This 14-day package extends those assets into a complete day-by-day training + testing system.
