# GatherSync Beta Full Walkthrough Script (Teleprompter)

Target length: 8 to 10 minutes

## Opening (0:00 - 0:40)

Welcome to the GatherSync beta walkthrough.

In this video, I will walk through the full tester workflow:
creating events, adding participants, sharing links, collecting responses, and finalizing event outcomes.

By the end, you will know exactly what to test and how to report feedback.

## Section 1: What Testers Should Validate (0:40 - 1:20)

Please focus on four areas.

First, event creation.

Second, participant management and sharing.

Third, public response flow.

Fourth, organizer-side updates and completion actions like archive and finalize.

## Section 2: Login and Event Dashboard (1:20 - 2:00)

Start by opening the beta URL.

Log in with your email and six-digit code.

After login, you should land on the Events screen.

From here, you can create a new event or open an existing one.

## Section 3: Flexible Event End-to-End (2:00 - 4:20)

Now let us create a flexible event.

Tap Create Event, enter the event name, set type to Flexible, choose month and year, then save.

Open the event detail screen and add participants.

Use any method you prefer, for example Manual, Contacts, Groups, or Directory.

After adding participants, tap a participant to edit availability.

Select several days as available and unavailable.

Return to event detail and confirm the event now reflects participant availability.

This is the core date-finding workflow.

## Section 4: Fixed Event RSVP Flow (4:20 - 6:00)

Next, create a fixed event.

Set a specific date and time.

Add participants as before.

Open a participant and set RSVP to Attending or Not Attending.

Return to event detail and verify RSVP summary counts update correctly.

This validates fixed-date decision tracking.

## Section 5: Public Participant Flow (6:00 - 7:30)

Now test the public side.

From event detail, copy or share the public event link.

Open that link in another tab.

Enter participant name, add optional notes, and submit response.

If the event is flexible, select available days.

If fixed, choose attending or not attending.

Submit and confirm success message appears.

Then return to organizer view and verify the response is visible.

## Section 6: Organizer Actions and Event Completion (7:30 - 8:50)

From the event menu, test key actions.

Edit event details.

Try share options such as Invite Participants or Share with Participants.

Test archive and unarchive.

If response data is sufficient, test Finalize Date and Archive.

Confirm the event moves to the expected state afterward.

## Section 7: How to Report Issues (8:50 - 9:40)

When reporting issues, include:
device, OS, browser, exact steps, expected behavior, actual behavior, and severity.

Use severity labels:
critical, major, or minor.

Include screenshot or short screen recording whenever possible.

Use the bug template provided in the tester packet.

## Closing (9:40 - 10:00)

That completes the full GatherSync beta walkthrough.

Thank you for testing and sharing actionable feedback.

Your reports directly improve launch readiness and product quality.
