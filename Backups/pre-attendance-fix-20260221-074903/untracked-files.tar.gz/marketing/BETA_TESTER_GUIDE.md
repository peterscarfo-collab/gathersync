# GatherSync Beta Tester Guide

This guide is for invited beta testers. Follow this once, then use it as a quick reference while testing.

## Purpose of This Beta

You are helping us validate real-world usability before broader release.

We especially want feedback on:

- Onboarding clarity
- Event creation flow
- Inviting and participant response flow
- Availability and RSVP reliability
- Mobile/desktop browser experience

## Access and Setup

1. Open the beta link shared by the team.
2. Log in with your email using the 6-digit code flow.
3. Use a modern browser (Chrome or Safari recommended).
4. Keep your test notes handy while you go.

## What to Test (Priority Order)

## 1) Create an Event

Create one **Flexible** event and one **Fixed** event.

For each event:

- Add clear event name
- Add meeting details (venue or virtual link)
- Save successfully
- Confirm event appears in Events list

## 2) Add Participants

Try at least 2 methods:

- Manual add
- Contacts, groups, or directory add

Check:

- Duplicate handling
- Required field behavior
- General speed and clarity

## 3) Share and Respond

1. Open event share options.
2. Copy/share participant link.
3. Open public link in another tab/incognito.
4. Submit a participant response.

Check:

- Link opens correctly
- Submission success message appears
- Organizer view updates with new response

## 4) Availability and RSVP

- For flexible event: mark different days and check calendar updates
- For fixed event: set attending/not attending and verify summary counts
- Add notes in at least one response

## 5) Event Completion Actions

From event menu, test:

- Edit event details
- Archive/unarchive
- Finalize date and archive (if applicable)

## Suggested Test Scenarios (30-45 mins total)

## Scenario A: Organizer Flow (15-20 mins)

1. Create event
2. Add 3 participants
3. Share link
4. Review incoming responses
5. Archive event

## Scenario B: Participant Flow (10-15 mins)

1. Open public link
2. Enter name
3. Submit availability or RSVP
4. Update response once

## Scenario C: Edge/Recovery (5-10 mins)

- Try back navigation during form edits
- Refresh and verify data persistence
- Try the same action twice (copy/share/submit)

## What Makes Feedback Most Useful

Please include:

- Device + OS + browser
- Exact page/screen
- What you expected
- What happened
- Severity (`critical`, `major`, `minor`)
- Screenshot or short video if possible

Use this template: `marketing/templates/BUG_REPORT_TEMPLATE.md`

## Severity Guidance

- `Critical`: blocks core flow, cannot continue
- `Major`: important issue with workaround
- `Minor`: cosmetic or low-impact issue

## Common Reporting Format (copy/paste)

```text
Title:
Environment: [device] / [OS] / [browser]
URL/Screen:
Steps:
1)
2)
3)
Expected:
Actual:
Severity: critical | major | minor
Attachment: [screenshot or clip]
```

## Completion Checklist

Before you finish, confirm you have tested:

- [ ] Login flow
- [ ] Create flexible event
- [ ] Create fixed event
- [ ] Add participants
- [ ] Share link and submit response
- [ ] RSVP and/or availability updates
- [ ] Archive/finalize behavior

Thank you for helping shape GatherSync before launch.
