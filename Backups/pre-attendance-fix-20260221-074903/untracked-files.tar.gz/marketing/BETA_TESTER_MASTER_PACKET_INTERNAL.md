<div style="color:#000 !important; background:#fff !important;">

# GatherSync Beta Tester Packet (Internal)

Wave 1  
Audience: Internal team only  
Purpose: Single operational document for planning, execution, and tester comms

Print-ready notes:

- This document uses text labels only (no color-dependent instructions).
- Export/print with black text on white background.
- Recommended print preset: grayscale or black-and-white.

---

## 1) Program Goal

Run a controlled external beta to validate end-to-end scheduling workflows before broader rollout.

Core validation targets:

1. Organizer flow works from create to finalize
2. Participant public response flow is reliable
3. Sharing and data update loops are clear
4. Critical and major issues are triaged and closed quickly

---

## 2) Tester-Facing Access Details

Beta URL:

- `https://preview.gathersync.app`

Login flow:

1. Tester enters email
2. Tester requests 6-digit code
3. Tester verifies code from inbox

Primary support contact:

- `hello@gathersync.app`

---

## 3) Wave Structure

Recommended approach:

- Wave 1: 5 testers
- Wave 2: 5 testers after first fix pass

Suggested tester mix per wave:

- 3 non-technical users
- 1 detail-focused reviewer
- 1 technical reviewer

---

## 4) What Testers Should Validate

1. Event creation (flexible and fixed)
2. Participant add/edit/share
3. Public page response submission
4. Organizer-side updates and counts
5. Archive/finalize completion actions

---

## 5) Daily Operating Cadence

Recommended daily rhythm:

- 9:00 AM - collect new reports
- 10:00 AM - triage and severity tagging
- 11:00 AM - prioritize fix queue
- 2:00 PM - verify fixes and regression-check
- 4:00 PM - send tester update note

---

## 6) Triage Model

Severity:

- `critical`: blocks core flow
- `major`: significant issue with workaround
- `minor`: cosmetic or low-impact

Area tags:

- `onboarding`
- `events`
- `participants`
- `sharing`
- `public-page`
- `ui`
- `performance`
- `other`

Status tags:

- `new`
- `in progress`
- `fixed - needs verification`
- `verified`
- `closed`

Prioritization order:

1. critical
2. major
3. minor (batch/polish pass)

---

## 7) Daily Checklist

Start of day:

- [ ] Review all new reports
- [ ] Request missing reproduction details
- [ ] Assign severity, area, and owner

During day:

- [ ] Fix critical/major first
- [ ] Re-test exact reproduction paths
- [ ] Run related regression checks

End of day:

- [ ] Publish tester update (fixed/in-progress/known issues)
- [ ] Update tracker status
- [ ] Confirm next-day priorities

---

## 8) Wave 1 Send Workflow

Canonical send file:

- `marketing/templates/WAVE1_TESTER_PACKET_EMAIL_READY.md`

Before send:

- [ ] Replace all TODO placeholders
- [ ] Validate every link once
- [ ] Send test email to yourself
- [ ] Validate links from inbox

Then:

- [ ] Send to first 5 testers
- [ ] Log sent timestamp
- [ ] Open issue intake channel and tracker

---

## 9) Placeholder Replacement Checklist

In packet templates, replace:

- `TODO_BETA_GUIDE_ID`
- `TODO_QUICKSTART_VIDEO_ID`
- `TODO_FULL_VIDEO_ID`
- `TODO_BUG_TEMPLATE_DOC_ID`
- `[TODO: Your Name]`
- `[TODO: Role]`
- Date/time placeholders (where present)

---

## 10) Quick Fallback Message (Link Correction)

```text
Quick update: one of the tester packet links was incorrect.
Please use this corrected link instead:
[INSERT_CORRECT_LINK]

Sorry about that, and thank you.
```

---

## 11) Exit Criteria

Wave can close when all are true:

- No open critical issues
- Major issues at acceptable level with known workarounds
- Core flows validated by multiple testers
- Stakeholder sign-off complete

---

## 12) Linked Working Docs

- `marketing/BETA_TESTER_MASTER_PACKET.md` (external PDF packet)
- `marketing/BETA_DAILY_OPS_CHECKLIST.md`
- `marketing/SEND_NOW.md`
- `marketing/BETA_TESTER_GUIDE.md`
- `marketing/BETA_TESTER_VIDEO_RUNBOOK.md`
- `marketing/RECORDING_DAY_PACK.md`
- `marketing/templates/TESTER_PACKET_EMAIL_TEMPLATE.md`
- `marketing/templates/WAVE1_TESTER_PACKET_EMAIL_READY.md`

</div>
