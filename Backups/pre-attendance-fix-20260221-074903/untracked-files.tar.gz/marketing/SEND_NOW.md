# GatherSync Beta Wave 1 - SEND NOW Checklist

Use this when you are ready to send Wave 1 tester emails.

Estimated time: 5 to 10 minutes

## 1) Open the Email Template

Use this file:

- `marketing/templates/WAVE1_TESTER_PACKET_EMAIL_READY.md`

## 2) Replace Required Placeholders

In that file, replace:

- `TODO_BETA_GUIDE_ID`
- `TODO_QUICKSTART_VIDEO_ID`
- `TODO_FULL_VIDEO_ID`
- `TODO_BUG_TEMPLATE_DOC_ID`
- `[TODO: Your Name]`
- `[TODO: Role]`

## 3) Quick Link Validation (Do Not Skip)

Click each final link once:

- [ ] Beta tester guide opens
- [ ] Quick-start video opens and plays
- [ ] Full walkthrough video opens and plays
- [ ] Bug template opens with correct permissions
- [ ] Beta link loads: `https://preview.gathersync.app`

## 4) Final Content Review

Before sending, confirm:

- [ ] Subject line is correct
- [ ] Tester name is personalized
- [ ] Timeline dates match your active wave
- [ ] Reward text is correct
- [ ] Contact email is `hello@gathersync.app`

## 5) Send to Wave 1 List

Recommended approach:

1. Send one test email to yourself first
2. Open all links from inbox preview
3. Send to first 5 testers

## 6) Immediate Post-Send Actions

Within 15 minutes:

- [ ] Post "Wave 1 sent" note in your team channel
- [ ] Start issue intake tracker
- [ ] Set first checkpoint reminder
- [ ] Keep `marketing/BETA_DAILY_OPS_CHECKLIST.md` open

## 7) If Something Breaks After Send

Use this fallback message:

```text
Quick update: one of the tester packet links was incorrect.
Please use this corrected link instead:
[INSERT_CORRECT_LINK]

Sorry about that, and thank you.
```

## Related Files

- `marketing/BETA_DAILY_OPS_CHECKLIST.md`
- `marketing/BETA_TESTER_GUIDE.md`
- `marketing/BETA_TESTER_VIDEO_RUNBOOK.md`
- `marketing/RECORDING_DAY_PACK.md`
