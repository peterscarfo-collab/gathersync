# GatherSync Tester Update Template

Subject: GatherSync Preview Update - [Wave X, Day Y]

Hi [Name],

Thanks again for helping with GatherSync preview testing.

What changed since last update:
- [Fix 1]
- [Fix 2]
- [Fix 3]

Please re-test these areas:
- [Area 1]
- [Area 2]

Preview link:
[INSERT_PREVIEW_LINK]

Reminder:
Approved active testers receive **12 months of Pro Version free**.

If you find issues, please send:
- Device + browser
- Expected vs actual behavior
- Screenshot/video (if possible)

Thanks,
[Your Name]
