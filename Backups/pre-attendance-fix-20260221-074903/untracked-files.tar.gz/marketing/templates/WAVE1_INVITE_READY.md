# Wave 1 Invite (Ready To Send)

Subject: GatherSync Preview Test Invite (12 Months Pro Free)

Hi [Name],

I am inviting a small first wave of testers to help validate the GatherSync preview before broader release.

Preview link:  
https://adorable-muffin-11ca8a.netlify.app/

What I need from you:

- Try the site end-to-end (home, pricing, download, and coming-soon pages)
- Tell me anything confusing, broken, or hard to use
- Share device + browser and a screenshot if possible

Thank you for helping. Approved active testers will receive **12 months of Pro Version free**.

If you are in, just reply "Yes" and I will mark you in the tester list.

Thanks,  
[Your Name]
