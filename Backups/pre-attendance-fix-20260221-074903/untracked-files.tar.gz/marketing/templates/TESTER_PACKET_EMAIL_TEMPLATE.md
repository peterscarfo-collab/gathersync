# GatherSync Beta Tester Packet Email Template

## Before Sending (Replace These Fields)

- [ ] `TODO_BETA_GUIDE_ID`
- [ ] `TODO_QUICKSTART_VIDEO_ID`
- [ ] `TODO_FULL_VIDEO_ID`
- [ ] `TODO_BUG_TEMPLATE_DOC_ID`
- [ ] `[TODO: DATE]` values
- [ ] `[TODO: Your Name]`
- [ ] `[TODO: Role]`

Subject: GatherSync Beta Tester Packet - Start Here

Hi [Tester Name],

Thank you for joining the GatherSync beta.

Please use this packet to get started:

## 1) Access

- Beta link: https://preview.gathersync.app
- Login: enter your email, then use the 6-digit code sent to your inbox

## 2) What to Review First

- Beta tester guide: https://drive.google.com/file/d/TODO_BETA_GUIDE_ID/view
- Quick-start video (2-3 min): https://www.loom.com/share/TODO_QUICKSTART_VIDEO_ID
- Full walkthrough video (8-10 min): https://www.loom.com/share/TODO_FULL_VIDEO_ID

## 3) Testing Focus

Please prioritize:

1. Event creation flow
2. Participant add/share flow
3. Public response flow (availability or RSVP)
4. Organizer updates and finalization flow

## 4) How to Report Issues

Please submit feedback using this bug template:

- Bug report template: https://docs.google.com/document/d/TODO_BUG_TEMPLATE_DOC_ID/edit

When reporting, include:

- Device + OS + browser
- Steps to reproduce
- Expected result
- Actual result
- Severity: critical / major / minor
- Screenshot or short clip if possible

## 5) Timeline

- Start by: [TODO: DATE]
- First feedback checkpoint: [TODO: DATE/TIME]
- Test window closes: [TODO: DATE]

## 6) Thank You

Approved active testers will receive 12 months of Pro free.

Your feedback directly improves launch quality - thank you for helping shape GatherSync.

- [TODO: Your Name]
- [TODO: Role]
- Contact: hello@gathersync.app
