Subject: Welcome to the GatherSync 14-Day Beta Program

Hi [First Name],

Thank you for joining the GatherSync beta.

Over the next 14 days, you will both learn the product and help us test every core workflow before launch.

## Your Beta Objectives

1. Learn how GatherSync works end-to-end (organizer and participant experience).
2. Run short daily tests (20-35 minutes/day).
3. Submit clear feedback so we can improve reliability and usability.

## Start Here

1. Read: `marketing/BETA_14_DAY_FULL_COVERAGE_PACKAGE.md`
2. Keep this guide open: `marketing/BETA_TESTER_GUIDE.md`
3. Use this format for issues: `marketing/templates/BUG_REPORT_TEMPLATE.md`

## Access

- Beta URL: [INSERT_BETA_URL]
- Login method: Email + 6-digit code

## Daily Expectation

- Complete the assigned day in the 14-day package.
- Submit at least one note daily (even if no bug is found).
- For any issue, include:
  - device/OS/browser
  - steps
  - expected vs actual
  - severity
  - screenshot/clip when possible

## End-of-Program Requirement

By Day 14, please submit:

- Top 3 strengths
- Top 3 blockers or frictions
- Launch recommendation: ready / ready with conditions / not ready

Thank you again for helping shape GatherSync.

Best,
[Your Name]
[Role]
