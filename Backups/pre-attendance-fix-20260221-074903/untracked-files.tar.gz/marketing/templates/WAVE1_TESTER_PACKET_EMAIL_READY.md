# GatherSync Wave 1 Tester Packet (Send-Ready Draft)

## Before Sending (Replace These Fields)

- [ ] `TODO_BETA_GUIDE_ID`
- [ ] `TODO_QUICKSTART_VIDEO_ID`
- [ ] `TODO_FULL_VIDEO_ID`
- [ ] `TODO_BUG_TEMPLATE_DOC_ID`
- [ ] `[TODO: Your Name]`
- [ ] `[TODO: Role]`

Subject: GatherSync Beta Wave 1 - Start Here

Hi [Tester Name],

Thank you for joining GatherSync Beta Wave 1.

Please use this packet to get started:

## 1) Access

- Beta link: https://preview.gathersync.app
- Login: enter your email, then use the 6-digit code sent to your inbox

## 2) Start Here

- Beta tester guide: https://drive.google.com/file/d/TODO_BETA_GUIDE_ID/view
- Quick-start video (2-3 min): https://www.loom.com/share/TODO_QUICKSTART_VIDEO_ID
- Full walkthrough video (8-10 min): https://www.loom.com/share/TODO_FULL_VIDEO_ID

## 3) Priority Testing Focus

1. Event creation flow
2. Participant add/share flow
3. Public response flow (availability or RSVP)
4. Organizer updates and finalization flow

## 4) Feedback Format

Please report issues with:

- Device + OS + browser
- Steps to reproduce
- Expected vs actual behavior
- Severity (critical / major / minor)
- Screenshot or short clip

Bug report template:

- https://docs.google.com/document/d/TODO_BUG_TEMPLATE_DOC_ID/edit

## 5) Wave 1 Timeline

- Start by: Monday, Feb 16, 2026
- First feedback checkpoint: Wednesday, Feb 18, 2026 at 10:00 AM
- Test window closes: Friday, Feb 20, 2026 at 6:00 PM

## 6) Thank You

Approved active testers will receive 12 months of Pro free.

Your feedback directly improves launch quality - thank you for helping shape GatherSync.

- [TODO: Your Name]
- [TODO: Role]
- Contact: hello@gathersync.app
