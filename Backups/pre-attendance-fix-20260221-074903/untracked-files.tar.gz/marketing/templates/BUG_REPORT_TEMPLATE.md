# GatherSync Bug Report Template

## Reporter

- Name:
- Date:

## Environment

- Device:
- OS version:
- Browser + version:
- URL tested:

## Summary

Short description of the issue.

## Steps to Reproduce

1.
2.
3.

## Expected Result

What you expected to happen.

## Actual Result

What happened instead.

## Severity

- [ ] Critical (blocks testing)
- [ ] Major (significant issue)
- [ ] Minor (small or cosmetic)

## Evidence

- Screenshot/video:
- Console errors (if any):
- Additional notes:
