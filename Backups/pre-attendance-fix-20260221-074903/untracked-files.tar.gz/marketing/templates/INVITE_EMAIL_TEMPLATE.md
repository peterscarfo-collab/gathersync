# GatherSync Beta Invite Template

Subject: Invite: GatherSync Preview Testing (12 Months Pro Free)

Hi [Name],

I am inviting a small group to test our GatherSync preview build before public rollout.

Preview link:
[INSERT_PREVIEW_LINK]

What to test:
- Overall clarity and first impression
- Navigation and calls to action
- App Store / Google Play coming-soon pages
- Anything confusing, broken, or hard to use

As a thank-you, approved active testers will receive **12 months of Pro Version free**.

Please send issues and feedback using this format:
- Device + browser
- What you expected
- What happened
- Screenshot (if possible)

Thank you — your feedback directly shapes the launch quality.

[Your Name]
