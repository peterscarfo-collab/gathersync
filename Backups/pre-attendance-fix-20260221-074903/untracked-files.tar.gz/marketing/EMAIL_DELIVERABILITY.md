# Email Deliverability Fix – Stop Emails Going to Spam/Junk

**Last updated: 12 February 2026**

Most GatherSync emails (magic login codes, invitations) were ending up in Spam/Junk. This doc outlines the fixes.

---

## 1. InstantDB Magic Code Emails (Login / New Account Verification)

GatherSync uses **InstantDB magic code auth** – `db.auth.sendMagicCode({ email })` sends a 6-digit code to the user’s email. That email is sent by InstantDB via **Postmark**.

### Default Sender Problem

By default, emails are sent from:

- `auth@pm.instantdb.com`

Generic sender domains like this often get filtered as spam by Gmail, Outlook, etc.

### Fix: Custom Sender on Your Domain

1. Go to **InstantDB Dashboard** → **Auth** tab → **Custom Magic Code Email**.
2. Set a custom “from” address on your domain, e.g.:
   - `auth@gathersync.app`
   - `login@gathersync.app`
   - `noreply@gathersync.app`
3. InstantDB/Postmark will email that address a **verification link**. Click it to confirm ownership.
4. After verification, magic code emails will be sent from your domain.

### Customize the Email Content

In the same dashboard section, you can change:

- **Subject** – must include `{code}`.
- **Body** – plain text or HTML; must include `{code}`.
- **Variables**: `{code}`, `{user_email}`, `{app_title}`.

Example subject:

```
Your GatherSync login code: {code}
```

This can help recipients recognize legitimate emails and reduce spam flags.

---

## 2. DNS Records for Your Domain

For any custom sender (`*@gathersync.app`), you need correct DNS so providers don’t mark mail as spam.

### SPF (Sender Policy Framework)

SPF says which servers can send mail for `gathersync.app`. Postmark will give records; typically you add something like:

```txt
Host: gathersync.app (or @)
Type: TXT
Value: v=spf1 include:spf.mtasv.net ~all
```

If you already have SPF, append: `include:spf.mtasv.net` and avoid multiple `v=spf1` records.

### DKIM (DomainKeys Identified Mail)

DKIM cryptographically signs messages. Postmark gives you DKIM records in the dashboard when you set up a custom domain. Add the TXT (or CNAME) records they provide for `gathersync.app` or the subdomain they specify.

### DMARC (Domain-based Message Authentication)

DMARC tells receiving servers how to treat mail that fails SPF/DKIM.

Example (monitoring mode):

```txt
Host: _dmarc.gathersync.app
Type: TXT
Value: v=DMARC1; p=none; rua=mailto:admin@gathersync.app; ruf=mailto:admin@gathersync.app; fo=1; adkim=s; aspf=s
```

Once deliverability is stable, you can move to `p=quarantine` or `p=reject`.

---

## 3. Best Practices for Deliverability

- **Use a real “from” name**: e.g. “GatherSync” instead of “noreply”.
- **Avoid spam-like content**: no ALL CAPS, few exclamation marks, limited links.
- **Warm up new senders**: start with low volume and increase gradually.
- **Monitor DMARC reports** at `admin@gathersync.app` to spot problems.
- **Avoid shared / free domains** for sending (e.g. gmail.com, outlook.com) – use your own domain.

---

## 4. Verification Checklist for New Account Emails

- [ ] Custom magic code sender set in InstantDB Dashboard.
- [ ] Sender address verified (confirmation link clicked).
- [ ] SPF record updated to include Postmark’s servers.
- [ ] DKIM records added per Postmark instructions.
- [ ] DMARC record in place (at least monitoring mode).
- [ ] Test: request magic code to a new address and confirm:
  - [ ] Email is received.
  - [ ] Email lands in Inbox (not Spam/Junk).
  - [ ] Code works for sign-in.

---

## 5. Where to Configure What

| Item              | Where to configure                                   |
|-------------------|------------------------------------------------------|
| Magic code sender | InstantDB Dashboard → Auth → Custom Magic Code Email |
| SPF/DKIM          | Domain DNS (e.g. Namecheap, Cloudflare)             |
| DMARC             | Domain DNS                                           |
| Postmark setup    | Via InstantDB when you add a custom sender          |

---

## Links

- [InstantDB Custom Emails](https://www.instantdb.com/docs/emails)
- [InstantDB Magic Codes](https://www.instantdb.com/docs/auth/magic-codes)
- [Postmark Sender Signatures](https://postmarkapp.com/support/article/1006-what-is-a-sender-signature) (for SPF/DKIM when using Postmark directly)
- [EMAIL_SETUP.md](./EMAIL_SETUP.md) – general GatherSync email setup
