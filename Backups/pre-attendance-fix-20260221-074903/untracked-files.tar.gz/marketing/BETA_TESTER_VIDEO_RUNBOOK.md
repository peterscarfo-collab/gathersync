# GatherSync Beta Tester Video Runbook

Use this to produce tester-facing videos quickly and consistently.

## Deliverables

Create two videos:

1. **Quick Start** (2-3 min)
2. **Full Walkthrough** (8-10 min)

These are for beta testers, not public marketing.

## Video 1: Quick Start (2-3 min)

## Goal

Get a tester from zero to first successful response in under 3 minutes.

## Scene Plan

### Scene 1: Login (0:00 - 0:30)

- Open beta URL
- Enter email
- Verify with 6-digit code

Narration:
"Sign in with your email and code. No password setup needed."

### Scene 2: Create Event (0:30 - 1:10)

- Create a flexible event
- Fill only key fields
- Save

Narration:
"Create an event first. Flexible events are best for date-finding."

### Scene 3: Add + Share (1:10 - 2:00)

- Add one or two participants
- Share public link
- Copy message

Narration:
"Add participants, then send the share link so they can respond."

### Scene 4: Participant Submission (2:00 - 2:40)

- Open public link
- Enter name
- Select availability
- Submit

Narration:
"Participants respond from the public page without organizer access."

### Scene 5: Confirm Update (2:40 - 3:00)

- Return to organizer event detail
- Show updated data

Narration:
"Responses update in the organizer view, so you can quickly find best dates."

## Video 2: Full Walkthrough (8-10 min)

## Goal

Give testers full confidence in every major flow they should exercise.

## Scene Plan

### Scene 1: What to Test (0:00 - 0:45)

- Open with 4 focus points:
  - Create
  - Add participants
  - Share/respond
  - Finalize/archive

### Scene 2: Flexible Event End-to-End (0:45 - 3:30)

- Create flexible event
- Add participants
- Edit availability for one participant
- Show best-day behavior

### Scene 3: Fixed Event End-to-End (3:30 - 5:30)

- Create fixed event with date/time
- Set RSVP statuses
- Show RSVP summary counts

### Scene 4: Public Link Experience (5:30 - 7:00)

- Open public event link
- Submit response and note
- Update response once

### Scene 5: Organizer Actions (7:00 - 9:00)

- Show event menu actions:
  - Edit details
  - Share options
  - Archive/unarchive
  - Finalize and archive

### Scene 6: Reporting Feedback (9:00 - 10:00)

- Show where to send feedback
- Show bug template fields

## Recording Checklist

- Use test account and test data only
- Increase zoom (125% to 150%)
- Keep cursor visible and movement slow
- Pause briefly before each click
- Avoid exposing personal data

## Editing Checklist

- Add section title cards
- Keep captions on
- Trim dead time
- Keep final exports at 1080p
- Name files clearly:
  - `gathersync-beta-quickstart-v1.mp4`
  - `gathersync-beta-full-walkthrough-v1.mp4`

## Optional Micro-Clips (for later social use)

Cut these 15-30 second clips from the same recording:

- "Create an event in 20 seconds"
- "Share participant link"
- "Submit RSVP from public page"
- "Finalize and archive event"
