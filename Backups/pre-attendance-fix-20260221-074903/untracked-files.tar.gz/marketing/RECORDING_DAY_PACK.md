# GatherSync Recording-Day Pack

Use this on recording day to move fast and keep edits simple.

## What You Will Produce

1. Quick-start video (2-3 min)
2. Full walkthrough video (8-10 min)
3. Optional micro-clips (15-30 sec each)

## Pre-Flight Checklist (10 minutes)

- [ ] Use demo account and test data only
- [ ] Turn off notifications
- [ ] Browser zoom set to 125% to 150%
- [ ] Cursor highlight enabled
- [ ] Clean desktop/browser tabs
- [ ] Mic check complete
- [ ] Screen resolution set to 1080p capture

## File Naming Convention

Use consistent names to simplify editing:

- Raw takes:
  - `raw-quickstart-take1.mp4`
  - `raw-walkthrough-take1.mp4`
- Exports:
  - `gathersync-beta-quickstart-v1.mp4`
  - `gathersync-beta-full-walkthrough-v1.mp4`

## Shot Order (Record in This Sequence)

Record each shot as a separate take. Pause 1 second before and after each action.

## Quick-Start Shots

1. Login flow
2. Create flexible event
3. Add participant
4. Share public link
5. Submit response from public page
6. Confirm organizer update

## Full Walkthrough Shots

1. Intro + test goals
2. Dashboard overview
3. Flexible event end-to-end
4. Fixed event RSVP flow
5. Public participant response flow
6. Organizer actions (edit/share/archive/finalize)
7. Bug reporting instructions
8. Closing

## Pause Markers (For Easy Cuts)

Use these every time:

- Before click: 1 second pause
- After page load: 1 second pause
- Before speaking next line: 0.5 second pause
- After section complete: 2 second pause

This makes jump cuts clean and predictable.

## On-Screen Text Overlay Pack

Add simple lower-third or title-card overlays.

## Quick-Start Overlay Sequence

1. `Step 1: Login`
2. `Step 2: Create Event`
3. `Step 3: Add Participants`
4. `Step 4: Share Link`
5. `Step 5: Submit Response`
6. `Done: Organizer View Updated`

## Full Walkthrough Overlay Sequence

1. `Section 1: What to Test`
2. `Section 2: Login and Dashboard`
3. `Section 3: Flexible Event Flow`
4. `Section 4: Fixed Event RSVP Flow`
5. `Section 5: Public Response Flow`
6. `Section 6: Organizer Actions`
7. `Section 7: Reporting Issues`
8. `Thanks for Testing GatherSync`

## Recommended Overlay Style

- Position: top-left or lower-third
- Duration: 2 to 3 seconds
- Background: dark with 70% opacity
- Text: white, medium weight, high contrast

## Micro-Clip Extraction Plan (Optional)

Cut these from the full walkthrough:

1. `Create an event in 20 seconds`
2. `Share participant link`
3. `Submit RSVP from public page`
4. `Finalize and archive event`

Each clip should:

- Be 15 to 30 seconds
- Start with action immediately
- End on a clear result state

## Voice Delivery Notes

- Keep pace steady and calm
- Use short direct sentences
- Avoid filler words
- Re-record any line with a stumble immediately

## Post-Production Checklist

- [ ] Trim dead time and mis-clicks
- [ ] Add overlays and section cards
- [ ] Add captions/subtitles
- [ ] Blur private information
- [ ] Normalize audio
- [ ] Export 1080p
- [ ] Verify playback on desktop and mobile

## Publish Checklist

- [ ] Upload quick-start video
- [ ] Upload full walkthrough video
- [ ] Copy both URLs into tester packet templates:
  - `marketing/templates/TESTER_PACKET_EMAIL_TEMPLATE.md`
  - `marketing/templates/WAVE1_TESTER_PACKET_EMAIL_READY.md`
- [ ] Send to Wave 1 testers
