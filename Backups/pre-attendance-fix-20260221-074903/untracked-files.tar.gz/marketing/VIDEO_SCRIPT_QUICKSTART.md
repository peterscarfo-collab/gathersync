# GatherSync Beta Quick-Start Video Script (Teleprompter)

Target length: 2 to 3 minutes

## Opening (0:00 - 0:20)

Hi, and welcome to GatherSync beta.

In this quick-start, I will show you how to log in, create an event, share it, and confirm a participant response in under three minutes.

## Step 1: Login (0:20 - 0:45)

First, open the beta link.

Enter your email address and request your login code.

Check your inbox for the six-digit code, enter it, and verify.

You are now signed in.

## Step 2: Create Event (0:45 - 1:20)

From the Events screen, tap Create Event.

Enter an event name.

Set the event type to Flexible.

Pick a month and year, then tap Create Event.

The new event is now saved and visible in your event list.

## Step 3: Add Participants and Share (1:20 - 2:00)

Open the event and tap Add Participant.

Add at least one person manually, then return to event details.

Tap the share option and copy or send the participant link.

This public link is what participants use to submit availability or RSVP.

## Step 4: Participant Submission (2:00 - 2:35)

Open the public link in a second tab or incognito window.

Enter participant name, select available days, and submit response.

You should see a success confirmation.

## Step 5: Confirm Update (2:35 - 3:00)

Return to the organizer event view.

You should now see updated participant response data.

That is the full quick-start flow: create, share, collect, and confirm.

Thanks for testing GatherSync beta.

## Optional Closing Line

If you hit any issue, please report it with device, browser, steps, expected result, actual result, and a screenshot.
