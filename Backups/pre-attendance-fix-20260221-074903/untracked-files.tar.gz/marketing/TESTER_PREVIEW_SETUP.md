# GatherSync Tester Preview Setup

Use this to run a safe external testing wave (up to 10 people) without impacting production.

## Goal

Create a shareable preview URL for marketing/testing while keeping the live app routing untouched.

## Recommended Structure

- Production app: `gathersync.app` (current app routing)
- Preview site: `preview.gathersync.app` (new subdomain)
- Source for preview: `marketing/rescued-site/`

## Step 1: Deploy Preview Site

Choose one:

1. Netlify drag-and-drop:
   - Zip `marketing/rescued-site/`
   - Deploy manually to Netlify
2. Netlify project deploy:
   - Connect repo/branch
   - Publish directory: `marketing/rescued-site`

Use the generated preview URL first (for example, `gathersync-preview.netlify.app`).

## Step 2: Add Preview Subdomain

In Netlify:

- Add custom domain: `preview.gathersync.app`

In Namecheap DNS for `gathersync.app`:

- Add CNAME:
  - Host: `preview`
  - Value: Netlify target shown in domain setup
  - TTL: automatic/default

Wait for DNS propagation, then verify `https://preview.gathersync.app`.

## Step 3: Protect Access (Optional but Recommended)

Use one of:

- Netlify password protection (if plan supports)
- Cloudflare Access in front of preview domain
- Share only with invited testers if no password option

## Step 4: Tester Program Settings

- Target: up to 10 external testers
- Offer: 12 months Pro free for approved active testers
- Suggested waves:
  - Wave 1: 5 testers
  - Wave 2: 5 testers after first bug-fix pass

## Step 5: What To Share With Testers

Send:

- Preview link: `https://preview.gathersync.app` (or temporary Netlify URL)
- Testing focus:
  - Clarity of messaging
  - Navigation and call-to-action flow
  - Coming-soon/beta signup experience
  - Browser/device issues
- Feedback template from `marketing/templates/BUG_REPORT_TEMPLATE.md`

## Step 6: Triage Feedback

Track each item as:

- Severity: `critical`, `major`, `minor`
- Area: `copy`, `layout`, `links`, `forms`, `mobile`, `browser`
- Status: `new`, `in progress`, `done`

## Notes

- Preview testers cannot affect production by browsing/testing.
- Only deployment credentials and repo write access can change what is live.
