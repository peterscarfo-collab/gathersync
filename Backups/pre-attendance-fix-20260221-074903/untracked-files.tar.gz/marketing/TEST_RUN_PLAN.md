# GatherSync External Test Run Plan

This plan is designed for up to 10 external testers with a 12-month Pro reward for approved active testers.

## Target Outcome

- Validate core marketing and onboarding flow before live rollout.
- Capture and resolve critical and major issues.
- Confirm readiness to proceed to mobile enhancement pass and final deployment.

## Test Waves

## Wave 1 (5 testers)

- Goal: find first-order blockers and confusing UX/content.
- Duration: 2-3 days.
- Tester mix:
  - 3 non-technical users
  - 1 detail-focused reviewer
  - 1 technical reviewer

### Wave 1 Focus

- Home page clarity and first impression
- CTA flow (`Download`, `Open Web App`, `Contact`)
- App Store and Google Play coming-soon pages
- Legal links and contact behavior
- Desktop browser consistency (Chrome, Safari, Edge/Firefox if possible)

## Wave 2 (5 testers)

- Goal: validate fixes and catch long-tail issues.
- Duration: 2-3 days after Wave 1 fixes.
- Tester mix:
  - 3 new users
  - 2 users from Wave 1 (regression check)

### Wave 2 Focus

- Regression pass on Wave 1 bug fixes
- Remaining copy/UX polish
- Mobile-browser sanity pass if available

## Severity Model

- `Critical`: blocks core flow (cannot continue testing)
- `Major`: significant issue but workaround exists
- `Minor`: cosmetic or low-impact

## Exit Criteria

Move to deployment prep when all are true:

- No open `Critical` bugs
- No more than 2 known `Major` bugs (with accepted temporary workaround)
- Legal/contact links verified
- CTA paths verified
- Stakeholder sign-off complete

## Reward Policy (12 Months Pro)

Recommended qualification rule:

- Tester submitted at least 2 actionable reports, and
- At least 1 report was accepted as valid bug/issue, or
- Tester completed both wave assignments and provided structured feedback

Track qualification in:

- `marketing/templates/TESTER_TRACKER.csv`

## Daily Operating Rhythm

Each day during active wave:

1. Collect feedback by 10:00 AM
2. Triage and severity-label by 11:00 AM
3. Fix critical/major issues first
4. Re-deploy preview
5. Send update note to testers

## Core Working Files

- Setup guide: `marketing/TESTER_PREVIEW_SETUP.md`
- Invite template: `marketing/templates/INVITE_EMAIL_TEMPLATE.md`
- Bug template: `marketing/templates/BUG_REPORT_TEMPLATE.md`
- Tracker: `marketing/templates/TESTER_TRACKER.csv`
