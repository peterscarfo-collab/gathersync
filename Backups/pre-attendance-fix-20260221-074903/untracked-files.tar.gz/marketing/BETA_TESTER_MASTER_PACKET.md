<div style="color:#000 !important; background:#fff !important;">

# GatherSync Beta Tester Packet

Wave 1  
Prepared for external testers

Print-ready notes:

- This document uses text labels only (no color-dependent instructions).
- Export/print with black text on white background.
- Recommended print preset: grayscale or black-and-white.

---

## Welcome

Thank you for joining the GatherSync beta.

Your feedback helps us improve usability, reliability, and overall launch quality.

In this beta, you will test the core planning flow:

1. Create events
2. Add participants
3. Share participant links
4. Collect availability or RSVP responses
5. Finalize scheduling decisions

---

## Access and Login

Beta URL:

- `https://preview.gathersync.app`

Login steps:

1. Enter your email
2. Request a login code
3. Enter the 6-digit code from your inbox

Recommended setup:

- Latest Chrome or Safari
- Stable internet connection
- Desktop first, then optional mobile browser test

---

## What to Test

## 1) Event Creation

Create:

- One flexible event
- One fixed-date event

Check:

- Form clarity
- Save behavior
- Correct display in event list/detail

## 2) Participant Management

Add participants using at least two methods:

- Manual entry
- Contacts, groups, or directory

Check:

- Duplicate handling
- Ease of editing
- Save reliability

## 3) Sharing and Public Response

1. Share event link
2. Open in a separate tab/incognito
3. Submit participant response

Check:

- Link validity
- Submission success
- Organizer-side update visibility

## 4) Availability and RSVP

- Flexible event: mark multiple days available/unavailable
- Fixed event: set attending or not attending
- Add optional notes

Check:

- Status/count accuracy
- Data persistence after refresh/navigation

## 5) Completion Actions

From event menu, test:

- Edit details
- Archive and unarchive
- Finalize date and archive

---

## Suggested Test Session (30-45 Minutes)

### Organizer Scenario (15-20 min)

1. Create event
2. Add 3 participants
3. Share participant link
4. Review responses
5. Archive event

### Participant Scenario (10-15 min)

1. Open public link
2. Enter name
3. Submit availability or RSVP
4. Update response once

### Reliability Scenario (5-10 min)

- Refresh during flow
- Repeat actions (copy/share/submit)
- Navigate away and back

---

## Quick-Start Video Script (2-3 Minutes)

Use this if you are recording a short tester intro video.

### Opening

Hi, and welcome to GatherSync beta.

In this quick-start, I will show you how to log in, create an event, share it, and confirm a participant response in under three minutes.

### Step 1: Login

Open the beta link, enter your email, request your code, and verify with the 6-digit code.

### Step 2: Create Event

Tap Create Event, enter a name, choose Flexible, select month/year, and save.

### Step 3: Add and Share

Open the event, add at least one participant, then share or copy the public link.

### Step 4: Submit Response

Open the public link in another tab, enter name, select days or RSVP, and submit.

### Step 5: Confirm Update

Return to organizer view and confirm response data updated.

### Closing

That is the full quick-start flow: create, share, collect, and confirm.

---

## Full Walkthrough Script (8-10 Minutes)

Use this for complete tester onboarding.

### Opening

Welcome to the GatherSync beta walkthrough.

In this video, I will walk through event creation, participant setup, sharing, response collection, and completion actions.

### Section 1: Testing Focus

Focus on:

1. Event creation
2. Participant + sharing flow
3. Public response flow
4. Organizer completion flow

### Section 2: Login and Dashboard

Log in with email code and review the Events screen.

### Section 3: Flexible Event End-to-End

Create flexible event, add participants, edit availability, verify updates.

### Section 4: Fixed Event RSVP

Create fixed event with date/time, set RSVP statuses, verify summary counts.

### Section 5: Public Participant Flow

Open public link, submit response with optional note, verify organizer updates.

### Section 6: Completion Actions

Test:

- Edit event
- Share options
- Archive/unarchive
- Finalize and archive

### Section 7: Reporting Issues

Report with environment, steps, expected vs actual, severity, and screenshot/clip.

### Closing

Thank you for testing and sharing actionable feedback.

---

## Feedback Template

Please submit issues using this format:

```text
Title:
Environment: [device] / [OS] / [browser]
URL/Screen:
Steps:
1)
2)
3)
Expected:
Actual:
Severity: critical | major | minor
Attachment: [screenshot or clip]
```

Severity definitions:

- `critical`: blocks core flow
- `major`: significant issue with workaround
- `minor`: cosmetic or low-impact

---

## Completion Checklist

Before finishing, confirm:

- [ ] Login works
- [ ] Flexible event created
- [ ] Fixed event created
- [ ] Participants added
- [ ] Share link tested
- [ ] Public submission tested
- [ ] Organizer updates verified
- [ ] Archive/finalize tested
- [ ] At least one feedback report submitted

---

## Contact

Questions or issues accessing beta:

- `hello@gathersync.app`

Thank you again for helping shape GatherSync.

</div>
