# GatherSync Deployment Architecture

**Last updated: 12 February 2026**

This document is the source of truth for what hosts what and how to deploy. Keep it updated when infrastructure changes.

---

## Domain Map

| Domain | Purpose | Hosting |
|--------|---------|---------|
| **gathersync.app** | Web app (production) – interactive app, events, login | Netlify |
| **app.gathersync.app** | Marketing site (production) – landing, coming soon, privacy/terms | Netlify |
| **adorable-muffin-11ca8a.netlify.app** | Web app beta | Netlify |
| **timely-melba-fbd7ee.netlify.app** | Marketing site beta | Netlify |
| **api.gathersync.app** | Backend API (OAuth, tRPC, public event lookup) | Fly.io (`gathersync-api-deploy`) |

---

## 1. Web App – Expo / React Native Web

- **Source:** Expo app (`app/`, `components/`, etc.)
- **Build:** `npm run build:web` → outputs to `dist-web/`
- **Hosting:** Netlify
- **Deploy:** Manual – run build, then deploy `dist-web/` to Netlify
- **Production:** gathersync.app
- **Beta:** adorable-muffin-11ca8a.netlify.app
- **Config:** `netlify.toml` in repo defines build command and API proxy

---

## 2. Marketing Site

- **Source:** `marketing/rescued-site/` (static HTML/CSS/JS)
- **Hosting:** Netlify (separate site from web app)
- **Deploy:** Upload or deploy `marketing/rescued-site/` to the Netlify site with marketing domains
- **Production:** app.gathersync.app
- **Beta:** timely-melba-fbd7ee.netlify.app
- **Contains:** Landing page, coming-soon app store/play store, privacy policy, terms of service

### Netlify proxy

- `/api/*` is proxied to `https://api.gathersync.app/api/:splat`
- So `fetch('/api/public/events/123')` from the web app reaches the Fly.io API

---

## 3. Backend API (api.gathersync.app)

- **Source:** `server/` (Express, tRPC, public REST API)
- **Hosting:** Fly.io (app name: `gathersync-api-deploy`)
- **Custom domain:** `api.gathersync.app` points to the Fly app

### Build & run

```bash
# Build (produces dist/index.js)
npm run build

# Run (server/index.js loads dist/index.js)
node server/index.js
```

### Deploy (Fly.io)

```bash
fly deploy
```

This uses the Dockerfile: installs deps, runs `npm run build`, runs `npm run build:web` for the bundled frontend, and starts with `node server/index.js`.

### Important env vars (Fly secrets)

- `INSTANT_APP_ID`
- `INSTANT_APP_ADMIN_TOKEN`
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`
- `FRONTEND_URL` (Netlify URL of the web app)
- `SESSION_SECRET` or `JWT_SECRET` / `COOKIE_SECRET`

---

## What We Are NOT Using

- **Railway:** Deprecated. Docs may still reference `gathersync-production.up.railway.app`; that is no longer in use.
- **Railway fix checklists:** Historical only.

---

## Data Flow (High Level)

```
User visits app.gathersync.app (marketing)
    → static HTML from Netlify (timely-melba / production)

User visits gathersync.app or adorable-muffin (web app)
    → Expo SPA loads from Netlify
    → /api/* requests → proxied to api.gathersync.app (Fly.io)
    → Fly.io talks to InstantDB for events/participants

Shared event link (e.g. /public-event?eventId=xxx)
    → Served by web app (gathersync.app or beta)
    → Fetches event from api.gathersync.app/api/public/events/:id
```

---

## Quick Reference: Deploy Commands

| Component | Command | Netlify site |
|-----------|---------|--------------|
| Web app | `npm run build:web` → deploy `dist-web/` | gathersync.app (prod), adorable-muffin (beta) |
| Marketing | Deploy `marketing/rescued-site/` | app.gathersync.app (prod), timely-melba (beta) |
| Backend API | `fly deploy` | Fly.io (api.gathersync.app) |
