# GatherSync User Manual

This guide is for day-to-day users of GatherSync: organizers and participants.

## What GatherSync Does

GatherSync helps a group choose the best meeting date.

- For **flexible events**, people mark the days they can attend.
- For **fixed events**, people RSVP as attending or not attending.
- Organizers can share a public link so participants respond from a browser.

## Core Terms

- **Event**: A meeting you are planning.
- **Flexible Event**: Participants mark availability across a month.
- **Fixed Event**: Organizer sets one date/time; participants RSVP.
- **Participant**: A person invited to respond.
- **Public Event Link**: Shareable URL where participants submit responses.

## Organizer Quick Start

1. Open GatherSync and sign in.
2. Create a new event.
3. Add participants.
4. Share the event link.
5. Track responses on the event detail screen.
6. Finalize and archive when complete.

## Sign In

GatherSync uses a passwordless login flow:

1. Enter your email.
2. Tap **Send Login Code**.
3. Enter the 6-digit code from email.
4. Tap **Verify Code**.

## Create an Event

1. From the Events screen, tap **Create Event** (or the `+` button).
2. Enter **Event Name**.
3. Choose **Event Type**:
   - **Flexible**: choose month and year.
   - **Fixed**: choose exact date and time.
4. Add optional details:
   - Team leader
   - Meeting type (In-person or Virtual)
   - Venue or meeting link
   - RSVP deadline
   - Notes
5. Tap **Create Event**.

## Add Participants

Open the event, then tap **Add Participant**. You can add people in several ways:

- **Manual**: Type name, phone, and email.
- **Contacts**: Load from your device contacts.
- **AI Import**: Paste message text and extract names.
- **Groups**: Reuse saved participant groups.
- **Directory**: Reuse participants from previous events.

## Share with Participants

From Event Detail:

- Tap the share icon or open the menu.
- Choose one of these options:
  - **Share Event** (general event share)
  - **Invite Participants**
  - **Share with Participants** (personalized messages)
  - **Email All Participants**

Participants use the public link to respond from web.

## Manage Availability and RSVP

### Flexible Events

- Tap a participant to open their availability editor.
- Tap dates to cycle status (available, unavailable, not set).
- Use quick actions for weekend presets.
- Add optional participant notes, phone, and email.

### Fixed Events

- Tap a participant.
- Set RSVP as **Attending** or **Not Attending**.
- Add optional notes.

## Read Results

In Event Detail:

- For flexible events, calendar heatmap indicates strongest dates.
- For fixed events, RSVP summary shows:
  - Attending
  - Not Attending
  - No Response

Tap RSVP counts to see who is in each group.

## Useful Event Actions (Menu)

From the event menu, you can:

- Edit event details
- Export to calendar
- Bulk import availability
- Copy event
- Save snapshot
- Finalize date and archive
- Archive / unarchive
- Delete event

## Participant Experience (Public Link)

When participants open a public event link, they can:

1. Enter their name (or tap their chip if listed).
2. Add optional notes.
3. Submit:
   - **Flexible**: choose available days.
   - **Fixed**: choose attending / not attending.

Responses are sent back to the organizer automatically.

## Tips for Better Scheduling

- Add participants before sharing to reduce duplicate names.
- Encourage participants to add notes when they decline or have constraints.
- Use **Share with Participants** for personalized links.
- Finalize once enough responses are in, then archive to keep active list clean.

## Troubleshooting

- **"Event not found" from shared link**  
  Ask organizer to open the event while online, then reshare the link.

- **Participant cannot submit**  
  Confirm they entered a name and selected at least one day for flexible events.

- **No participants in event**  
  Add participants first, then try sharing again.

- **Duplicate participant warning**  
  Edit existing participant instead of adding a second entry.
