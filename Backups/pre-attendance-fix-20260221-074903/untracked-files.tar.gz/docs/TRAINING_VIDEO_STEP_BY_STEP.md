# GatherSync Training Video (Step-by-Step)

Use this as a practical recording script for onboarding new users.

## Goal and Audience

- **Goal**: Show how to run an event in GatherSync from start to finish.
- **Audience**: New organizers and first-time participants.
- **Target length**: 8 to 12 minutes.

## Recording Prep Checklist

Before recording:

1. Use a clean demo account.
2. Prepare one sample event name (for example: "Team Planning Session").
3. Prepare 4 to 6 sample participants.
4. Have one browser tab ready for the public event link view.
5. Turn on cursor highlights and zoom for readability.
6. Silence notifications.

## Video Structure

1. Intro (30 sec)
2. Organizer workflow (5 to 7 min)
3. Participant workflow (2 to 3 min)
4. Wrap-up and next steps (30 sec)

## Scene-by-Scene Script

### Scene 1: Intro (0:00 - 0:30)

**On screen**
- GatherSync home or Events screen.

**Narration**
- "In this video, you'll learn how to create an event, invite people, collect availability or RSVPs, and finalize a date using GatherSync."

### Scene 2: Login (0:30 - 1:00)

**On screen**
1. Open login.
2. Enter email.
3. Send login code.
4. Enter verification code.

**Narration**
- "GatherSync uses passwordless login. Enter your email, request a code, then verify to sign in."

### Scene 3: Create Event (1:00 - 2:15)

**On screen**
1. Tap `+` or **Create Event**.
2. Enter event name.
3. Show both event types quickly:
   - Flexible
   - Fixed
4. Fill optional meeting details (venue or meeting link).
5. Tap **Create Event**.

**Narration**
- "Flexible events collect available days across a month. Fixed events collect RSVPs for one date and time."

### Scene 4: Add Participants (2:15 - 4:00)

**On screen**
1. Open event detail.
2. Tap **Add Participant**.
3. Demonstrate these tabs quickly:
   - Manual
   - Contacts
   - Groups (or Directory)
4. Add at least 3 participants.

**Narration**
- "You can add participants manually, from contacts, from saved groups, or from your directory of prior participants."

### Scene 5: Share the Event (4:00 - 5:00)

**On screen**
1. Open menu in event detail.
2. Show **Invite Participants** or **Share with Participants**.
3. Copy/share a generated message.
4. Mention personalized links by participant name.

**Narration**
- "Sharing sends participants to a public event page where they can respond without organizer access."

### Scene 6A: Flexible Availability Flow (5:00 - 6:30)

**On screen**
1. Tap a participant in event detail.
2. Open availability editor.
3. Tap several days to mark available/unavailable.
4. Return to event detail and show updated calendar strength.

**Narration**
- "For flexible events, each participant can mark specific available days. GatherSync then highlights the strongest dates."

### Scene 6B: Fixed RSVP Flow (optional alternate clip)

**On screen**
1. Open a fixed event.
2. Tap participant.
3. Set RSVP to attending / not attending.
4. Return and show RSVP summary.

**Narration**
- "For fixed events, RSVP status is tracked in the event summary."

### Scene 7: Participant View (6:30 - 8:30)

**On screen**
1. Open shared public link in browser.
2. Enter participant name (or tap preset chip).
3. Add optional note.
4. Submit response.
5. Return to organizer view and show updated result.

**Narration**
- "Participants can respond directly from the public page. The organizer sees updates automatically."

### Scene 8: Finalize and Archive (8:30 - 9:30)

**On screen**
1. Open event menu.
2. Show **Finalize Date & Archive**.
3. Show archive behavior in event list.

**Narration**
- "Once responses are in, finalize the date and archive the event to keep your active list clean."

### Scene 9: Close (9:30 - 10:00)

**On screen**
- Return to Events screen.

**Narration**
- "You now know the full GatherSync workflow: create, invite, collect responses, and finalize."

## Shot List (Quick Reference)

- Events dashboard
- Login flow
- Create event form
- Add participant tabs
- Event detail menu
- Public event response page
- Finalize and archive action

## Recording Tips

- Use 125% to 150% browser zoom for readability.
- Keep mouse movement slow and intentional.
- Pause 1 second before each click for editing flexibility.
- Record one clean take per scene so clips are easy to reorder.

## Post-Production Checklist

1. Add section title cards for each scene.
2. Add captions (recommended).
3. Blur private data (emails, phones).
4. Export 1080p.
5. Save final file with date version, for example:
   - `gathersync-training-v1-2026-02-13.mp4`

## Optional Follow-Up Videos

- "Advanced participant management" (Groups, Directory, AI Import)
- "Running fixed-date RSVP events"
- "Sharing and messaging best practices"
