# GatherSync Go/No-Go Release Checklist

Last updated: 2026-02-18 (prefilled)
Owner: Peter
Release target: Web (Netlify)

Use this as the final release gate. Mark each item pass/fail and add short evidence.

## 1) Build and Stability Gate

- [x] `pnpm run check` passes in current branch
  - Evidence: TypeScript gate cleared successfully on 2026-02-18 (`tsc --noEmit` exit 0).
- [x] `pnpm run build:web` completes and `dist-web/` is produced
  - Evidence: Web export succeeded on 2026-02-18 and `dist-web/` generated.
- [ ] No blocker errors in browser console on load/login/event flows
  - Evidence:

Gate decision for this section: [ ] PASS  [ ] FAIL (pending console verification)

## 2) Smoke Tests (Must Pass)

- [x] Login magic code flow works end-to-end (request code -> receive -> verify -> session active)
  - Browsers tested: Mobile + desktop web
  - Evidence: User confirmed login works in deployed app.
- [x] Create event flow works (new event created, saved, and visible after refresh)
  - Browsers tested: Desktop Chrome
  - Evidence: Created event with name/date/month and 2 participants; saved; visible in list; persisted after browser refresh.
- [x] RSVP flow works (submit RSVP, update RSVP, reflected in event/admin views)
  - Browsers tested: Mobile + desktop web
  - Evidence: User confirmed RSVP submission on mobile and reflected on desktop.

Gate decision for this section: [x] PASS  [ ] FAIL

## 3) Manual Critical Path (Web)

- [x] Desktop browser pass (Chrome)
  - Evidence: User validated core flows on deployed web app.
- [x] Mobile browser pass (Safari or Chrome mobile)
  - Evidence: User validated responsive layout + RSVP on mobile.
- [x] Admin areas used for launch are functional (`/admin/participants`, `/admin/promotions`)
  - Evidence: User validated both `admin/participants` and `admin/promotions`.
- [x] Public event page is functional (open, respond, submit)
  - Evidence: User submitted attendance/RSVP successfully from mobile.

Gate decision for this section: [ ] PASS  [ ] FAIL

## 4) Email Deliverability Confidence

- [x] Daily magic code inbox test completed (Day 1)
  - Recipient(s):
  - Result: Completed previously during deliverability setup; record exact recipient and timestamp.
- [ ] Daily magic code inbox test completed (Day 2)
  - Recipient(s):
  - Result:
- [ ] Daily magic code inbox test completed (Day 3)
  - Recipient(s):
  - Result:
- [ ] Gmail inbox placement acceptable
  - Evidence:
- [ ] Outlook inbox placement acceptable
  - Evidence:

Gate decision for this section: [ ] PASS  [ ] FAIL

## 5) Launch Operations Readiness

- [ ] Support response plan ready (owner, response window, escalation path)
  - Evidence:
- [ ] Backups verified (latest backup exists and restore steps confirmed)
  - Evidence:
- [ ] Rollback plan documented (who, how, when)
  - Evidence:
- [ ] Known issues list prepared and non-blocking
  - Evidence:

Gate decision for this section: [ ] PASS  [ ] FAIL

## 6) Technical Debt Exception Log (Pre-Launch)

Track temporary exceptions accepted for this release (example: files with `// @ts-nocheck`).

| Exception | Scope | Risk | Owner | Target Fix Date |
|---|---|---|---|---|
| `// @ts-nocheck` in selected legacy frontend files | Type safety reduced in those files | Medium | Peter | 2026-03-05 |
| Web push registration temporarily disabled on web (`hooks/use-push-notifications.ts`) | Browser push notifications unavailable until VAPID config is added | Low | Peter | 2026-03-12 |
| Backup restore UX decision (keep backup vs optional restore-and-delete prompt) | Current behavior keeps backups after restore; revisit preference later | Low | Peter | 2026-03-15 |

Gate decision for this section: [ ] PASS  [ ] FAIL

## Final Decision

- Overall release decision: [ ] GO  [ ] NO-GO
- Decision owner:
- Decision date/time:
- Notes:
  - Netlify deploy already completed for current build.
