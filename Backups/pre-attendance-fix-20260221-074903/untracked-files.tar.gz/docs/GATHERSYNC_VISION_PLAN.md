# GatherSync Vision & Feature Plan

**Goal:** Make "Let's GatherSync it" the go-to phrase when organizing group get-togethers.  
**Focus:** Simplify repeatable events, unify participant identity, and improve discovery.

---

## Current State (What You Have)

| Concept | How It Works Today |
|---------|--------------------|
| **Events** | Creator-owned. Each event has its own participant records. |
| **Participants** | Event-scoped only. Name, phone, email, availability. No global "person" identity. |
| **Group Templates** | Store participant **names** only. Reusable for quick add. |
| **Copy/Duplicate** | "Copy event" → create-event with `copyFrom` + `participants` (names only—phone/email lost). Templates screen uses past events as templates. |

**Gaps:**
1. Duplicating loses contact details (only names passed).
2. Same person added to multiple events = multiple records. No deduplication.
3. No way to "find" someone you've used before except via Groups or manual search.
4. Participants don't have an "events panel" of events they're invited to (only creator sees their events).

---

## Feature 1: Smart Event Duplication

**Idea:** One action to duplicate a repeatable event, change date/time/venue, and re-use the same participant list (with full contact info). New event appears in your events panel; participants get the link as before.

### Implementation Approach

**Option A: Enhance existing Copy flow (simplest)**  
1. Fix `handleCopyEvent` in event-detail: pass **full participant objects** (name, phone, email, `personId` when we have it), not just names.  
2. Create-event: when `copyFrom` + `participants`, create new participants from full data.  
3. Add a "Duplicate" action that opens a pre-filled create screen with date defaulted to "next occurrence" (e.g. next month same weekday).

**Option B: Dedicated "Duplicate Event" flow**  
1. New screen or modal: "Duplicate: [Event Name]"  
2. Pre-fill: date (editable), time, venue, meeting details, participants.  
3. Single "Create" → new event + participants in one mutation.  
4. Option: "Duplicate for next month" / "Same day next month" shortcuts.

**Recommendation:** Start with **Option A** — fix the copy flow to preserve full participant data. Add a "Duplicate for [next month/same day next year]" shortcut on the event card or detail screen. Low effort, high impact.

**Schema impact:** None if we only pass participant data. Optional: add `personId` to participants when we implement global people (Feature 2).

---

## Feature 2: Global People (Person Identity)

**Idea:** Each distinct person gets a system ID. When adding to an event, the app can recognize "this is John from last time" and pre-fill or link.

### Schema Design

Introduce a new entity: **`people`** (or `contacts` — user-scoped, not global platform)

```
people: {
  id: string (system ID)
  name: string
  phone?: string (normalized, indexed)
  email?: string (indexed)
  createdAt, updatedAt
  creator: user (who "owns" this contact - privacy)
}
```

**Participants** get an optional link:

```
participants: {
  ...existing fields...
  person: people (optional link - "this participant row refers to this person")
}
```

**Why user-scoped (creator) and not global?**  
- Privacy: "My contacts" vs "everyone on the platform."  
- Simpler to ship: no cross-user search, no consent flows.  
- Later you can add opt-in "public profile" for users who want discoverability (Feature 3).

### Matching Logic

When adding a participant (manual, contacts, or paste):

1. **By email** (if provided): exact match on `people` for this user.  
2. **By phone** (if provided): normalize, then match.  
3. **By name** (weak): only suggest matches if email/phone also match (avoid false positives).

If match found → create participant with `person: personId`. If not → create new `people` record, then participant linked to it.

### Migration

- Existing participants: no `person` link. They stay as "anonymous" participants.  
- New participants: create/link `people` as above.  
- Optional backfill: script to merge duplicates (same email/phone) into one `people` and link participants.

---

## Feature 3: People Search (Facebook/Instagram-style)

**Idea:** When adding to an event, type a name/email and get suggestions from your previous participants and contacts.

### Scope (Phased)

**Phase 1 — Your own data**  
- Search over `people` you've created.  
- Search over participant names/emails from your events.  
- Typeahead in add-participant: "John" → John Smith, John Doe (from your events/people).

**Phase 2 — Platform discovery** (requires Feature 2 + product decision)  
- Users opt into "discoverable" profile (name, photo, maybe bio).  
- Search finds other GatherSync users who've opted in.  
- "Add from GatherSync" vs "Add new contact".

**Phase 3 — Social graph**  
- "People who attended events with you" (requires events you're both in).  
- "People in your contacts who use GatherSync".  

**Recommendation:** Start with Phase 1. It uses only your data, no new permissions, and delivers most of the benefit for repeatable groups.

### Implementation (Phase 1)

1. **`people` entity** with `creator` link (from Feature 2).  
2. **Search API/hook:** `usePeopleSearch(query, userId)` — query `people` where creator=userId, filter by name/email/phone contains query.  
3. **Add-participant UI:** Search bar with debounced fetch. Show matches with name, email, phone. On select → add as participant with `person` link.

---

## Feature 4: "Events I'm Invited To" (Participants' Panel)

**Idea:** If a participant is a GatherSync user, they see events they've been invited to in their own panel—not only via the public link.

### Requirements

1. **Link participant → user:** Need a way to know "this participant row = this app user".  
   - Options: participant has `userId` when they've signed up; or we match by email when they open the app.

2. **New view:** "My events" vs "Events I created". Tab or filter.

3. **Permissions:** Events you're invited to: you can view, maybe edit availability. Creator retains control.

### Complexity

- Requires participants to have accounts and be linked.  
- Matching by email is fuzzy (same email, different person).  
- Best done after People + opt-in flow.

**Recommendation:** Defer until you have solid person identity and a clear "join via link" → "create account" flow.

---

## Recommended Roadmap

| Phase | Features | Effort | Impact |
|-------|----------|--------|--------|
| **1** | Fix copy/duplicate to preserve full participant data; add "Duplicate" shortcut | Low | High — removes most "mucking around" for repeatable events |
| **2** | Add `people` entity, link participants, matching by email/phone | Medium | High — enables search, dedup, "add known person" |
| **3** | People search (Phase 1) in add-participant | Low–Medium | High — "type John, get your Johns" |
| **4** | "Events I'm invited to" for logged-in participants | Medium | Medium — nicer UX for regular participants |
| **5** | Platform discovery, "Let's GatherSync it" growth features | Higher | Strategic |

---

## "Let's GatherSync it" — Brand & Growth

To make the phrase stick:

1. **In-product copy:** Use it in share flows, empty states, success messages.  
   - "Event created! Share the link—Let's GatherSync it."  
   - "Organizing lunch? GatherSync it."

2. **Share/export:** Pre-filled message: "We're using GatherSync to find a time—[link]. Let's GatherSync it!"

3. **Landing/marketing:** Tagline, testimonials, examples of the phrase in use.

4. **Viral loop:** When someone opens a public event link, prompt: "Get the app to add your availability and get reminders. GatherSync it."

---

## Summary: Best Way Forward

1. **Now:** Fix duplication to pass full participant data and add a clear "Duplicate" action.  
2. **Next:** Introduce `people`, link participants, add email/phone matching when adding.  
3. **Then:** People search in add-participant so you can quickly re-add past participants.  
4. **Later:** Participants' panel, platform discovery, social features.

This keeps each step shippable and valuable without a massive rewrite.
