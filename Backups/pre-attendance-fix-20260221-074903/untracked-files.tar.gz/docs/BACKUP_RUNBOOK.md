# Backup Runbook

This runbook gives a repeatable process to keep GatherSync data recoverable.

## Daily quick check

Run:

```bash
pnpm backup:status
```

Expected result: `OK: latest backup is within 24h`.

If you want a different threshold:

```bash
BACKUP_MAX_AGE_HOURS=12 pnpm backup:status
```

## Create a fresh backup

Run:

```bash
pnpm backup:export
```

Output file is saved in `backups/` as `gathersync-backup-<timestamp>.json`.

## One-command verify

Run:

```bash
pnpm backup:verify
```

This exports a new backup, then confirms freshness and prints record counts.

## Dropbox copy (offsite)

Run:

```bash
pnpm backup:dropbox
```

This will:
1. export a fresh backup,
2. copy the newest backup file to Dropbox, and
3. run a freshness check.

Default Dropbox location:
- `~/Dropbox/GatherSync-Backups`

If your Dropbox folder is different, set:

```bash
DROPBOX_BACKUP_DIR=/absolute/path/to/your/dropbox/folder pnpm backup:dropbox
```

## Restore drill checklist (recommended weekly)

1. Create a fresh backup with `pnpm backup:export`.
2. Copy the newest backup file to an offsite location (cloud drive or encrypted storage).
3. Verify backup file opens and has expected top-level keys (`version`, `exportedAt`, `counts`, `data`).
4. Confirm counts are plausible for your current production size.
5. Record the timestamp and operator in your operations notes.

## Security quick checks for production

1. Ensure debug routes are disabled unless explicitly needed:
   - `ENABLE_DEBUG_ROUTES` should be unset or `false`.
2. Ensure strong secrets are set:
   - `SESSION_SECRET`
   - `INSTANT_APP_ADMIN_TOKEN`
3. Ensure cookie and CORS env values are reviewed:
   - `COOKIE_DOMAIN` only if required
   - `EXTRA_CORS_ORIGINS` minimized to known origins
4. Never commit backup JSON files or `.env` files to git.
