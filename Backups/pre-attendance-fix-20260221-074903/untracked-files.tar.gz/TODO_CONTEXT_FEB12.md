# GatherSync – Session Notes (12 Feb 2026)

**Context:** To revisit tomorrow. Conversation covered RSVP stats, public event links, and API/Netlify config.

---

## 1. Completed Today

### RSVP & Participants
- Stats consistency: `getActiveParticipants()` and `getRsvpCounts()` used everywhere (event card, event detail, calendar grid)
- RSVP numbers clickable: event card → navigates to event-detail with `showRsvp` param; event detail → modal with participant list
- RSVP status circles on participants list: green (attending), red (not-attending), grey (no-response)
- RSVP circles increased to 18×18px, explicit hex colors (#10B981, #EF4444, #6B7280)
- Edit-availability now writes to InstantDB via `eventMutations.updateParticipant()` (RSVP changes persist)

### Public Event / API Proxy
- **Netlify proxy fixed:** `dist-web/_redirects` now includes `/api/*` → `https://api.gathersync.app/api/:splat` (build script updated in `package.json`)
- Public-event page has InstantDB fallback for logged-in users when API returns 404
- `.netlify/netlify.toml` publish path corrected from absolute to `dist-web`

### Cursor Rule
- Rule added: run `npm run build:web` after frontend changes (`.cursor/rules/build-and-deploy.mdc`)

---

## 2. Open Issue: Public Event 404

**Symptom:** Event `0b875021-a842-408d-bfd7-8217b047241e` shows "Event not found" on public link.

**Facts:**
- Event exists in InstantDB (confirmed in Explorer)
- API returns `{"error":"Event not found"}` (JSON 404, not Netlify HTML)
- API proxy via Netlify is working (app shows its own "Event not found" UI)
- App ID from InstantDB dashboard: `60c16f5e-9cfa-4e25-bd1e-a68d1cdcb925`

**Root cause:** Fly.io API is likely using the wrong `INSTANT_APP_ID` or `INSTANT_APP_ADMIN_TOKEN`, so it is querying a different app (or failing) instead of the one where the event exists.

**Next steps:**
1. Run `fly secrets list -a gathersync-api-deploy`
2. Ensure `INSTANT_APP_ID=60c16f5e-9cfa-4e25-bd1e-a68d1cdcb925`
3. Get admin token from InstantDB Dashboard → Settings → Admin token
4. Run `fly secrets set INSTANT_APP_ADMIN_TOKEN=<token> -a gathersync-api-deploy`
5. Redeploy or restart: `fly deploy -a gathersync-api-deploy` or `fly apps restart gathersync-api-deploy`
6. Re-test: `curl "https://gathersync.app/api/public/events/0b875021-a842-408d-bfd7-8217b047241e"`

---

## 3. Deploy Checklist

- **Web app:** Deploy `dist-web/` to Netlify (build includes correct `_redirects`)
- **Backend:** After fixing Fly secrets, run `fly deploy -a gathersync-api-deploy`

---

## 4. Important Files Touched

| File | Purpose |
|------|---------|
| `package.json` | Build script writes `_redirects` with API proxy |
| `dist-web/_redirects` | Generated during build – API proxy + SPA fallback |
| `app/public-event.tsx` | InstantDB fallback when API 404s |
| `app/edit-availability.tsx` | Calls `eventMutations.updateParticipant()` for InstantDB |
| `instant.perms.ts` | Events & participants `data.ref()` fixes for delete |
| `lib/participant-status.ts` | `getActiveParticipants()`, `getRsvpCounts()` |
| `components/event-card.tsx` | RSVP numbers navigate to event-detail with showRsvp |
| `app/event-detail.tsx` | RSVP modal, status circles, showRsvp param handling |
| `.netlify/netlify.toml` | Publish path set to `dist-web` |
| `.cursor/rules/build-and-deploy.mdc` | Auto run build:web after frontend changes |

---

## 5. Quick Commands

```bash
# Build web (creates dist-web with correct _redirects)
npm run build:web

# Check Fly secrets
fly secrets list -a gathersync-api-deploy

# Set InstantDB credentials
fly secrets set INSTANT_APP_ID=60c16f5e-9cfa-4e25-bd1e-a68d1cdcb925 -a gathersync-api-deploy
fly secrets set INSTANT_APP_ADMIN_TOKEN=<from-instantdb-dashboard> -a gathersync-api-deploy

# Redeploy backend
fly deploy -a gathersync-api-deploy
```

---

Enjoy your dinner. See you tomorrow.
