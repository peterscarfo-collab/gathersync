export type EventType = "flexible" | "fixed";
export type RSVPStatus = "attending" | "not-attending" | "no-response";
export type RecurrencePattern = "weekly" | "biweekly" | "monthly";
export interface DayAvailability {
  date: string;
  availableCount: number;
  unavailableCount: number;
  noResponseCount: number;
  participants: Array<{
    id: string;
    name?: string;
    status: "available" | "unavailable" | "no-response";
  }>;
}

export interface BestDay {
  date: string;
  availableCount: number;
  percentage: number;
}

export interface Participant {
  id: string;
  name?: string;
  phone?: string;
  email?: string;
  availability?: Record<string, boolean>;
  unavailableAllMonth?: boolean;
  notes?: string;
  source?: string;
  rsvpStatus?: RSVPStatus | string;
  eventId?: string;
  deletedAt?: string | Date | null;
  createdAt?: string | Date;
  updatedAt?: string | Date;
  [key: string]: unknown;
}

export interface Event {
  id: string;
  name?: string;
  eventType?: EventType | string;
  month?: number;
  year?: number;
  fixedDate?: string;
  fixedTime?: string;
  reminderDaysBefore?: number;
  reminderScheduled?: boolean;
  archived?: boolean;
  finalized?: boolean;
  finalizedDate?: string;
  teamLeader?: string;
  teamLeaderPhone?: string;
  meetingType?: string;
  venueName?: string;
  venueAddress?: string;
  venueContact?: string;
  venuePhone?: string;
  meetingLink?: string;
  rsvpDeadline?: string;
  meetingNotes?: string;
  participants?: Participant[];
  deletedAt?: string | Date | null;
  createdAt?: string | Date;
  updatedAt?: string | Date;
  [key: string]: unknown;
}

export interface EventSnapshot {
  id: string;
  eventId?: string;
  name?: string;
  eventData?: Event;
  event?: Event;
  savedAt?: string | Date;
  [key: string]: unknown;
}

export interface GroupTemplate {
  id: string;
  name?: string;
  participantNames?: string[];
  createdAt?: string | Date;
  [key: string]: unknown;
}

export interface RecurringEventTemplate {
  id: string;
  name?: string;
  description?: string;
  pattern?: RecurrencePattern;
  dayOfWeek?: number;
  dayOfMonth?: number;
  participants?: Participant[];
  createdAt?: string | Date;
  updatedAt?: string | Date;
  [key: string]: unknown;
}

export interface AttendanceRecord {
  participantId: string;
  participantName?: string;
  eventId: string;
  status?: RSVPStatus | string;
  date?: string;
  [key: string]: unknown;
}
