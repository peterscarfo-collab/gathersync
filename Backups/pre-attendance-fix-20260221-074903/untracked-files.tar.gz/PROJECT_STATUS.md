# GatherSync Project Status

Last updated: 2026-02-11 (end of day)  
Working branch: `morning-backup`

## Current Snapshot

- Netlify beta login loop is resolved for current tester run.
- External testing has resumed (4 testers active again).
- Several web screens were stabilized to use InstantDB-backed data consistently.
- Deployment for beta is currently done via **manual Netlify publish** using `dist-web`.

## What Happened Today (2026-02-11)

### 1) Login loop returned on Netlify beta

Symptoms:
- Google OAuth completed, then users looped back to login or appeared unauthenticated.

Primary fixes applied:
- `server/_core/google-oauth.ts`
  - successful callback redirect now includes `sessionToken` in frontend URL again.
- `server/_core/cookies.ts`
  - removed hardcoded `.fly.dev` cookie domain; now optional via `COOKIE_DOMAIN`.
- `server/_core/index.ts`
  - CORS now supports Netlify origins (`*.netlify.app`) and optional `EXTRA_CORS_ORIGINS`.
- `app/oauth/callback.tsx`
  - accepts both `sessionToken` and legacy `token`.
- `netlify.toml`
  - moved `/api/*` redirect above SPA catch-all so API calls are not swallowed.

### 2) Post-login editing regressions surfaced

After login was fixed, multiple edit flows failed with loading/session/not-found behavior.

Root pattern:
- Screens were mixing local storage and server/trpc assumptions while live data was now primarily InstantDB.
- Some screens showed loading indefinitely or "not found" when local cache did not yet contain the event.

Stabilization fixes:
- `app/edit-meeting-details.tsx`
  - moved to InstantDB live event hydration (`useEvent`) for reliable load.
  - fixed infinite loading condition.
  - prevented form overwrite while typing by narrowing hydration effect deps.
  - hardened save path: seed local cache before auto-sync update if missing.
- `app/edit-availability.tsx`
  - moved to InstantDB live event hydration (`useEvent`).
  - fixed loading fallback behavior.
  - hardened save path: seed local cache before local update if missing.
- `app/add-participant.tsx`
  - fallback to live InstantDB event if local cache miss occurs.
  - ensure event is seeded into local cache before local append/update.
  - replaced silent returns with explicit error alerts where event context is missing.

## Environment/Deploy Notes That Matter

### Netlify frontend environment values

For current beta URL:
- `EXPO_PUBLIC_OAUTH_REDIRECT_URL=https://adorable-muffin-11ca8a.netlify.app`
- `EXPO_PUBLIC_INSTANT_APP_ID=<active instant app id>`
- `EXPO_PUBLIC_API_BASE_URL=https://api.gathersync.app`

### Backend environment values

- `FRONTEND_URL=https://adorable-muffin-11ca8a.netlify.app`
- optional: `EXTRA_CORS_ORIGINS=<comma-separated>`
- leave `COOKIE_DOMAIN` empty unless a specific shared domain is required.

### Netlify deployment mode (important)

- This site is currently using manual deploy behavior.
- Standard workflow used today:
  1. Run `npm run build:web`
  2. Upload `dist-web/` in Netlify manual deploy area.

## Files Touched In This Stabilization Session

- `netlify.toml`
- `server/_core/index.ts`
- `server/_core/cookies.ts`
- `server/_core/google-oauth.ts`
- `app/oauth/callback.tsx`
- `app/edit-meeting-details.tsx`
- `app/edit-availability.tsx`
- `app/add-participant.tsx`

## Current Known State (End of Day)

- Login flow works again for beta testers.
- Edit meeting details route loads and can be edited after latest patches.
- Edit availability route patched to use same event source path as event detail.
- Add participant flow patched to survive local-cache misses common in beta path.
- Testers are able to continue; monitor for any remaining data-sync edge cases.

## Resume Tomorrow: Fast Checklist

1. Re-test end-to-end on beta URL:
   - login
   - open event
   - edit meeting details + save
   - edit availability + save
   - add participant + verify persists
2. If any failure persists, capture:
   - exact URL
   - action taken
   - visible error text
3. If stable, do cleanup pass:
   - standardize event screens on one source of truth (InstantDB first)
   - reduce mixed local/cloud fallback complexity
   - add lightweight debug panel for auth + event loading state

## Prior Milestone Context (Kept for Continuity)

- Backup branch and marketing prep work remain in place from prior checkpoint.
- Original marketing/tester docs are still in `marketing/` and remain valid for operations.
