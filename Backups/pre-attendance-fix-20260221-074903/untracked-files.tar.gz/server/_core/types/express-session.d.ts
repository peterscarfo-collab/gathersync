import "express-session";

declare module "express-session" {
  interface SessionData {
    user?: {
      id?: string;
      openId?: string;
      email?: string;
      name?: string;
      loginMethod?: string;
      role?: string;
      lastSignedIn?: Date;
      [key: string]: unknown;
    };
  }
}
