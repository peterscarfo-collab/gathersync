#!/usr/bin/env node
/**
 * Captures screenshots of the public event participant flow.
 * Usage: node scripts/capture-public-event-flow.mjs [eventUrl] [outputDir]
 */
import puppeteer from "puppeteer";
import { mkdir } from "fs/promises";
import path from "path";
import { existsSync } from "fs";

// Prefer system Chrome if Puppeteer's Chromium isn't installed
const CHROME_PATHS = [
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/Applications/Chromium.app/Contents/MacOS/Chromium",
  "/usr/bin/google-chrome",
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser",
];
const executablePath = CHROME_PATHS.find((p) => existsSync(p)) || undefined;

const EVENT_URL =
  process.argv[2] ||
  "https://adorable-muffin-11ca8a.netlify.app/public-event?eventId=49028be2-37d9-4b5e-a393-4b25127a01df";

const OUTPUT_DIR =
  process.argv[3] || path.join(process.cwd(), "marketing/screenshots/ai-guys-mar2");

// Viewport for readable screenshots (desktop-like, not too wide)
const VIEWPORT = { width: 1200, height: 900 };

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  await mkdir(OUTPUT_DIR, { recursive: true });

  const launchOpts = {
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
  };
  if (executablePath) launchOpts.executablePath = executablePath;

  const browser = await puppeteer.launch(launchOpts);

  const page = await browser.newPage();

  // Set viewport for readable content
  await page.setViewport(VIEWPORT);

  const saveScreenshot = async (filename, description) => {
    const filepath = path.join(OUTPUT_DIR, filename);
    await page.screenshot({ path: filepath, fullPage: false });
    return { filepath, description };
  };

  const results = [];

  // Handle native alert (React Native Web uses window.alert on success)
  page.on("dialog", async (dialog) => {
    await dialog.accept();
  });

  try {
    // 1. Navigate and wait for load
    await page.goto(EVENT_URL, {
      waitUntil: "networkidle0",
      timeout: 15000,
    });

    // Brief wait for any client-side render
    await delay(1500);

    // Check for loading or error states
    const loadingSelector = "text=Loading event";
    const errorSelector = "text=Event not found";
    const eventNameExists = await page
      .evaluate(() => document.body.textContent?.includes("GatherSync"))
      .catch(() => false);
    const isLoading = await page
      .$(loadingSelector)
      .then((el) => !!el)
      .catch(() => false);
    const isError = await page
      .$(errorSelector)
      .then((el) => !!el)
      .catch(() => false);

    if (isLoading) {
      await delay(3000);
    }

    // 1) Initial page view with event title/date
    results.push(
      await saveScreenshot(
        "01-initial-page-view.png",
        "Initial page view with event title and date visible"
      )
    );

    // 2) Scroll to name input section and screenshot
    await page.evaluate(() => window.scrollTo(0, 350));
    await delay(500);
    results.push(
      await saveScreenshot(
        "02-name-input.png",
        "Section where user enters their name"
      )
    );

    // 3) Check if flexible (calendar) or fixed (RSVP) event
    const isFlexible = await page
      .evaluate(() => {
        const text = document.body.textContent || "";
        return text.includes("Mark your availability") || text.includes("Available Days");
      })
      .catch(() => false);

    if (isFlexible) {
      // Scroll to calendar
      await page.evaluate(() => window.scrollTo(0, 550));
      await delay(500);
      results.push(
        await saveScreenshot(
          "03-availability-days.png",
          "Selecting availability days (flexible event)"
        )
      );
    } else {
      // Fixed event - RSVP options
      results.push(
        await saveScreenshot(
          "03-rsvp-options.png",
          "RSVP options (Attending / Not Attending)"
        )
      );
    }

    // 4) Fill form: name
    await page.evaluate(() => window.scrollTo(0, 350));
    const nameInput = await page.$('input[placeholder*="name"], input[placeholder*="Name"], input[placeholder*="Or enter"]');
    if (nameInput) {
      await nameInput.type("Test Participant", { delay: 50 });
    }

    // Select availability or RSVP
    if (isFlexible) {
      const clicked = await page.evaluate(() => {
        const clickables = document.querySelectorAll("[style*='borderRadius'], button, div[role='button']");
        for (const el of clickables) {
          const t = el.textContent?.trim();
          if (t === "5" || t === "15") {
            el.click();
            return true;
          }
        }
        return false;
      });
      if (!clicked) {
        const day5 = await page.evaluateHandle(() => {
          const all = document.querySelectorAll("*");
          for (const el of all) {
            if (el.textContent?.trim() === "5" && el.offsetParent) return el;
          }
          return null;
        });
        const el = day5.asElement();
        if (el) await el.click();
      }
    } else {
      await page.evaluate(() => {
        const els = document.querySelectorAll("button, [role=button], div, span");
        for (const el of els) {
          if (el.textContent?.includes("Attending") && !el.textContent?.includes("Not Attending")) {
            el.click();
            return;
          }
        }
      });
    }

    await delay(500);

    // Screenshot before submit
    await page.evaluate(() => window.scrollTo(0, 600));
    await delay(300);

    // 4) Submit button visible
    results.push(
      await saveScreenshot(
        "04-before-submit.png",
        "Form filled, ready to submit"
      )
    );

    // Click Submit
    await page.evaluate(() => {
      const btns = document.querySelectorAll("button, [role=button], div, span, a");
      for (const b of btns) {
        if (b.textContent?.trim() === "Submit Response") {
          b.click();
          return;
        }
      }
    });

    // Wait for success (Alert or success message)
    await delay(2500);

    // 5) Success confirmation
    await page.waitForFunction(
      () =>
        document.body?.textContent?.includes("Response Submitted") ||
        document.body?.textContent?.includes("Thank you for responding"),
      { timeout: 5000 }
    ).catch(() => {});

    await page.evaluate(() => window.scrollTo(0, 450));
    await delay(500);

    results.push(
      await saveScreenshot(
        "05-success-confirmation.png",
        "Success confirmation after submit"
      )
    );

    // 6) Update response option
    await page.evaluate(() => window.scrollTo(0, 550));
    await delay(300);

    results.push(
      await saveScreenshot(
        "06-update-response-option.png",
        "Update my response option"
      )
    );
  } catch (err) {
    console.error("Error during capture:", err.message);
    // Save a screenshot of current state for debugging
    try {
      const debugPath = path.join(OUTPUT_DIR, "debug-on-error.png");
      await page.screenshot({ path: debugPath });
      results.push({
        filepath: debugPath,
        description: `Debug screenshot (error: ${err.message})`,
      });
    } catch (_) {}
  } finally {
    await browser.close();
  }

  return results;
}

main()
  .then((results) => {
    console.log("\n--- Screenshots captured ---\n");
    results.forEach(({ filepath, description }) => {
      console.log(`${path.resolve(filepath)}`);
      console.log(`  ${description}\n`);
    });
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
