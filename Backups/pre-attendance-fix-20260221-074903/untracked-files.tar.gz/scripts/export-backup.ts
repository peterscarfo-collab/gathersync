#!/usr/bin/env tsx
import "dotenv/config";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { adminDb } from "../lib/admin-db";

type BackupCounts = {
  users: number;
  events: number;
  participants: number;
  snapshots: number;
  templates: number;
  pushTokens: number;
};

type BackupPayload = {
  version: "1.0";
  exportedAt: string;
  appId: string;
  counts: BackupCounts;
  data: Record<string, unknown>;
};

function timestampForFilename(date = new Date()): string {
  return date.toISOString().replace(/[:.]/g, "-");
}

async function exportBackup() {
  const appId = process.env.INSTANT_APP_ID;
  if (!appId) {
    throw new Error("INSTANT_APP_ID is not set. Cannot export backup.");
  }
  if (!process.env.INSTANT_APP_ADMIN_TOKEN) {
    throw new Error("INSTANT_APP_ADMIN_TOKEN is not set. Cannot export backup.");
  }

  console.log("[Backup] Fetching data from InstantDB...");
  const result = await adminDb.query({
    $users: {},
    events: { creator: {} },
    participants: { event: {} },
    eventSnapshots: { creator: {}, event: {} },
    groupTemplates: { creator: {} },
    pushTokens: { user: {} },
  });

  const counts: BackupCounts = {
    users: result.$users?.length ?? 0,
    events: result.events?.length ?? 0,
    participants: result.participants?.length ?? 0,
    snapshots: result.eventSnapshots?.length ?? 0,
    templates: result.groupTemplates?.length ?? 0,
    pushTokens: result.pushTokens?.length ?? 0,
  };

  const payload: BackupPayload = {
    version: "1.0",
    exportedAt: new Date().toISOString(),
    appId,
    counts,
    data: result as unknown as Record<string, unknown>,
  };

  const backupsDir = path.resolve(process.cwd(), "backups");
  await mkdir(backupsDir, { recursive: true });

  const filename = `gathersync-backup-${timestampForFilename()}.json`;
  const filepath = path.join(backupsDir, filename);
  await writeFile(filepath, JSON.stringify(payload, null, 2), "utf8");

  console.log("[Backup] Export complete:");
  console.log(`- File: ${filepath}`);
  console.log(`- Exported: ${payload.exportedAt}`);
  console.log(
    `- Counts: users=${counts.users}, events=${counts.events}, participants=${counts.participants}, snapshots=${counts.snapshots}, templates=${counts.templates}, pushTokens=${counts.pushTokens}`
  );
}

exportBackup().catch((error) => {
  console.error("[Backup] Export failed:", error);
  process.exit(1);
});
