#!/usr/bin/env tsx
import "dotenv/config";
import { copyFile, mkdir, readdir, stat } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

type BackupFile = {
  file: string;
  fullPath: string;
  mtimeMs: number;
};

function getDefaultDropboxBackupDir(): string {
  return path.join(os.homedir(), "Dropbox", "GatherSync-Backups");
}

async function getLatestBackupFile(backupsDir: string): Promise<BackupFile | null> {
  const entries = await readdir(backupsDir, { withFileTypes: true });
  const candidates = entries
    .filter((entry) => entry.isFile() && /^gathersync-backup-.*\.json$/.test(entry.name))
    .map((entry) => entry.name);

  if (candidates.length === 0) return null;

  const withStats = await Promise.all(
    candidates.map(async (file) => {
      const fullPath = path.join(backupsDir, file);
      const s = await stat(fullPath);
      return { file, fullPath, mtimeMs: s.mtimeMs };
    })
  );

  withStats.sort((a, b) => b.mtimeMs - a.mtimeMs);
  return withStats[0];
}

async function copyLatestBackupToDropbox() {
  const backupsDir = path.resolve(process.cwd(), "backups");
  const dropboxBackupDir = process.env.DROPBOX_BACKUP_DIR?.trim() || getDefaultDropboxBackupDir();

  const latest = await getLatestBackupFile(backupsDir);
  if (!latest) {
    throw new Error("No local backup files found. Run `pnpm backup:export` first.");
  }

  await mkdir(dropboxBackupDir, { recursive: true });
  const destination = path.join(dropboxBackupDir, latest.file);
  await copyFile(latest.fullPath, destination);

  console.log("[Backup] Dropbox copy complete:");
  console.log(`- Source: ${latest.fullPath}`);
  console.log(`- Destination: ${destination}`);
}

copyLatestBackupToDropbox().catch((error) => {
  console.error("[Backup] Dropbox copy failed:", error);
  process.exit(1);
});
