#!/usr/bin/env tsx
import { readdir, readFile, stat } from "node:fs/promises";
import path from "node:path";

type BackupFile = {
  file: string;
  fullPath: string;
  mtimeMs: number;
};

type BackupPayload = {
  version: string;
  exportedAt: string;
  appId: string;
  counts?: {
    users?: number;
    events?: number;
    participants?: number;
    snapshots?: number;
    templates?: number;
    pushTokens?: number;
  };
};

function formatHours(ms: number): string {
  return (ms / (1000 * 60 * 60)).toFixed(2);
}

async function getLatestBackupFile(backupsDir: string): Promise<BackupFile | null> {
  let entries;
  try {
    entries = await readdir(backupsDir, { withFileTypes: true });
  } catch (error: any) {
    if (error?.code === "ENOENT") {
      return null;
    }
    throw error;
  }
  const candidates = entries
    .filter((entry) => entry.isFile() && /^gathersync-backup-.*\.json$/.test(entry.name))
    .map((entry) => entry.name);

  if (candidates.length === 0) return null;

  const withStats = await Promise.all(
    candidates.map(async (file) => {
      const fullPath = path.join(backupsDir, file);
      const s = await stat(fullPath);
      return { file, fullPath, mtimeMs: s.mtimeMs };
    })
  );

  withStats.sort((a, b) => b.mtimeMs - a.mtimeMs);
  return withStats[0];
}

async function backupStatus() {
  const maxAgeHours = Number(process.env.BACKUP_MAX_AGE_HOURS ?? "24");
  const now = Date.now();
  const backupsDir = path.resolve(process.cwd(), "backups");

  const latest = await getLatestBackupFile(backupsDir);
  if (!latest) {
    console.error("[Backup] No backup files found in ./backups");
    process.exit(1);
  }

  const raw = await readFile(latest.fullPath, "utf8");
  const payload = JSON.parse(raw) as BackupPayload;
  const exportedAtMs = new Date(payload.exportedAt).getTime();

  if (!Number.isFinite(exportedAtMs)) {
    console.error(`[Backup] Latest backup has invalid exportedAt: ${payload.exportedAt}`);
    process.exit(1);
  }

  const ageMs = now - exportedAtMs;
  const maxAgeMs = maxAgeHours * 60 * 60 * 1000;

  console.log("[Backup] Latest backup status:");
  console.log(`- File: ${latest.fullPath}`);
  console.log(`- Version: ${payload.version}`);
  console.log(`- ExportedAt: ${payload.exportedAt}`);
  console.log(`- AgeHours: ${formatHours(ageMs)}`);
  if (payload.counts) {
    console.log(
      `- Counts: users=${payload.counts.users ?? 0}, events=${payload.counts.events ?? 0}, participants=${payload.counts.participants ?? 0}, snapshots=${payload.counts.snapshots ?? 0}, templates=${payload.counts.templates ?? 0}, pushTokens=${payload.counts.pushTokens ?? 0}`
    );
  }

  if (ageMs > maxAgeMs) {
    console.error(
      `[Backup] STALE: backup is older than ${maxAgeHours}h threshold (current age ${formatHours(ageMs)}h).`
    );
    process.exit(1);
  }

  console.log(`[Backup] OK: latest backup is within ${maxAgeHours}h.`);
}

backupStatus().catch((error) => {
  console.error("[Backup] Status check failed:", error);
  process.exit(1);
});
