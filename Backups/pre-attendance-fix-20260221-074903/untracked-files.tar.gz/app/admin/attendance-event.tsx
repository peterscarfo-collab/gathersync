// @ts-nocheck
import { useEffect, useMemo, useState } from 'react';
import { Alert, Platform, Pressable, ScrollView, Share, StyleSheet, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useThemeColor } from '@/hooks/use-theme-color';
import { eventsLocalStorage } from '@/lib/local-storage';
import type { Event } from '@/types/models';

type AttendanceState = 'unchecked' | 'attended' | 'not-attended';
type ParticipantView = 'all' | 'unchecked' | 'attended' | 'not-attended';

export default function AdminAttendanceEventScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { eventId } = useLocalSearchParams<{ eventId: string }>();
  const tintColor = useThemeColor({}, 'tint');
  const cardBg = useThemeColor({ light: '#f5f5f5', dark: '#2a2a2a' }, 'background');

  const [event, setEvent] = useState<Event | null>(null);
  const [participantView, setParticipantView] = useState<ParticipantView>('all');
  const [updatingKey, setUpdatingKey] = useState<string | null>(null);

  useEffect(() => {
    const loadEvent = async () => {
      if (!eventId) return;
      try {
        const loaded = await eventsLocalStorage.getById(eventId);
        setEvent(loaded && !loaded.deletedAt ? loaded : null);
      } catch (error) {
        console.error('Failed to load event attendance:', error);
      }
    };
    loadEvent();
  }, [eventId]);

  const formatEventDate = (current: Event) => {
    if (current.eventType === 'fixed' && current.fixedDate) {
      return new Date(current.fixedDate).toLocaleDateString();
    }
    return `${current.month}/${current.year}`;
  };

  const getActiveParticipants = (current: Event) =>
    current.participants.filter((participant) => !participant.deletedAt);

  const getLatestAttendanceRecord = (current: Event) => {
    if (!current.attendanceRecords || current.attendanceRecords.length === 0) return null;
    return [...current.attendanceRecords].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    )[0];
  };

  const getAttendanceMap = (current: Event): Record<string, AttendanceState> => {
    const map: Record<string, AttendanceState> = {};
    const participants = getActiveParticipants(current);
    participants.forEach((participant) => {
      map[participant.name] = 'unchecked';
    });

    const latest = getLatestAttendanceRecord(current);
    if (!latest) return map;

    if (latest.statuses && typeof latest.statuses === 'object') {
      participants.forEach((participant) => {
        const value = latest.statuses[participant.name];
        if (value === 'attended' || value === 'not-attended' || value === 'unchecked') {
          map[participant.name] = value;
        }
      });
      return map;
    }

    const attended = latest.attendees || [];
    attended.forEach((name: string) => {
      if (name in map) map[name] = 'attended';
    });
    return map;
  };

  const persistAttendanceMap = async (current: Event, nextMap: Record<string, AttendanceState>) => {
    const attendees = Object.keys(nextMap).filter((name) => nextMap[name] === 'attended');
    const nextRecords = current.attendanceRecords ? [...current.attendanceRecords] : [];
    const nextRecord = {
      date: new Date().toISOString(),
      attendees,
      statuses: nextMap,
    };

    if (nextRecords.length === 0) {
      nextRecords.push(nextRecord);
    } else {
      const latestIndex = nextRecords.reduce((bestIdx, record, idx, arr) => {
        return new Date(record.date).getTime() > new Date(arr[bestIdx].date).getTime() ? idx : bestIdx;
      }, 0);
      nextRecords[latestIndex] = {
        ...nextRecords[latestIndex],
        ...nextRecord,
      };
    }

    const nextEvent = { ...current, attendanceRecords: nextRecords } as Event;
    setEvent(nextEvent);
    await eventsLocalStorage.update(current.id, { attendanceRecords: nextRecords } as Partial<Event>);
    return nextEvent;
  };

  const toggleAttendance = async (participantName: string) => {
    if (!event) return;
    const latestMap = getAttendanceMap(event);
    const currentState = latestMap[participantName] || 'unchecked';
    const nextState: AttendanceState =
      currentState === 'unchecked' ? 'attended' : currentState === 'attended' ? 'not-attended' : 'unchecked';

    if (event.eventType === 'fixed' && event.fixedDate) {
      const eventDateStart = new Date(event.fixedDate);
      eventDateStart.setHours(0, 0, 0, 0);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (eventDateStart.getTime() > today.getTime() && currentState !== 'attended' && nextState === 'attended') {
        Alert.alert(
          'Attendance Locked',
          'This event is in the future. You can remove incorrect marks, but new attendance can only be added on or after the event date.'
        );
        return;
      }
    }

    const key = `${event.id}:${participantName}`;
    setUpdatingKey(key);
    const previousEvent = event;

    try {
      const nextMap = { ...latestMap, [participantName]: nextState };
      await persistAttendanceMap(event, nextMap);
    } catch (error) {
      setEvent(previousEvent);
      console.error('Failed to update attendance:', error);
      Alert.alert('Update failed', 'Could not update attendance. Please try again.');
    } finally {
      setUpdatingKey(null);
    }
  };

  const buildCsv = () => {
    if (!event) return '';
    const statuses = getAttendanceMap(event);
    const rows = event.participants
      .filter((participant) => !participant.deletedAt)
      .map((participant) => ({
        participant,
        state: statuses[participant.name] || 'unchecked',
      }))
      .sort((a, b) => a.participant.name.localeCompare(b.participant.name));

    let csv = 'Event Name,Event Date,Participant,Attendance Status,Finalized\n';
    rows.forEach(({ participant, state }) => {
      const status = state === 'attended' ? 'Attended' : state === 'not-attended' ? 'Did Not Attend' : 'Unchecked';
      const finalized = state === 'unchecked' ? 'No' : 'Yes';
      csv += `"${event.name.replace(/"/g, '""')}","${formatEventDate(event)}","${participant.name.replace(/"/g, '""')}","${status}","${finalized}"\n`;
    });
    return csv;
  };

  const exportReport = () => {
    if (!event) return;
    const csv = buildCsv();
    if (Platform.OS === 'web') {
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `attendance-${event.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } else {
      Share.share({
        message: csv,
        title: `${event.name} attendance`,
      });
    }
  };

  const getCountByState = (state: AttendanceState) => {
    if (!event) return 0;
    const map = getAttendanceMap(event);
    return Object.values(map).filter((value) => value === state).length;
  };

  const finalizeAttendance = async () => {
    if (!event) return;
    const map = getAttendanceMap(event);
    const uncheckedCount = Object.values(map).filter((value) => value === 'unchecked').length;
    if (uncheckedCount === 0) {
      Alert.alert('Already finalized', 'No unchecked participants remain.');
      return;
    }

    Alert.alert(
      'Finalize Attendance',
      `Mark all ${uncheckedCount} unchecked participants as "Did not attend"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Finalize',
          style: 'destructive',
          onPress: async () => {
            try {
              const nextMap = { ...map };
              Object.keys(nextMap).forEach((name) => {
                if (nextMap[name] === 'unchecked') nextMap[name] = 'not-attended';
              });
              await persistAttendanceMap(event, nextMap);
              Alert.alert('Finalized', 'Attendance is now finalized with only attended / did not attend states.');
            } catch (error) {
              console.error('Failed to finalize attendance:', error);
              Alert.alert('Finalize failed', 'Could not finalize attendance.');
            }
          },
        },
      ]
    );
  };

  const exportPdfReport = () => {
    if (!event) return;
    if (Platform.OS !== 'web') {
      Alert.alert('PDF Export', 'PDF export is available on web. On mobile, use Export CSV and share it.');
      return;
    }

    const map = getAttendanceMap(event);
    const rows = getActiveParticipants(event)
      .map((participant) => {
        const state = map[participant.name] || 'unchecked';
        const label = state === 'attended' ? 'Attended' : state === 'not-attended' ? 'Did not attend' : 'Unchecked';
        return `<tr><td>${participant.name}</td><td>${label}</td></tr>`;
      })
      .join('');

    const html = `
      <html>
      <head>
        <title>${event.name} Attendance Report</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, Arial, sans-serif; padding: 24px; }
          h1 { margin: 0 0 8px; }
          p { margin: 4px 0; color: #444; }
          table { width: 100%; border-collapse: collapse; margin-top: 18px; }
          th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
          th { background: #f5f5f5; }
        </style>
      </head>
      <body>
        <h1>${event.name} - Attendance Report</h1>
        <p>Event date: ${formatEventDate(event)}</p>
        <p>Attended: ${getCountByState('attended')} | Did not attend: ${getCountByState('not-attended')} | Unchecked: ${getCountByState('unchecked')}</p>
        <p>Generated: ${new Date().toLocaleString()}</p>
        <table>
          <thead><tr><th>Participant</th><th>Status</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </body>
      </html>
    `;
    const win = window.open('', '_blank');
    if (!win) {
      Alert.alert('Popup blocked', 'Please allow popups to export PDF.');
      return;
    }
    win.document.open();
    win.document.write(html);
    win.document.close();
    win.focus();
    win.print();
  };

  const archiveEventOnly = async () => {
    if (!event) return;
    const unchecked = getCountByState('unchecked');
    const proceedArchive = async (markUncheckedAsDidNotAttend: boolean) => {
      try {
        const currentMap = getAttendanceMap(event);
        const nextMap = { ...currentMap };
        if (markUncheckedAsDidNotAttend) {
          Object.keys(nextMap).forEach((name) => {
            if (nextMap[name] === 'unchecked') nextMap[name] = 'not-attended';
          });
        }
        const nextEventFromAttendance = await persistAttendanceMap(event, nextMap);
        const archivedEvent = {
          ...nextEventFromAttendance,
          archived: true,
          finalized: true,
          finalizedDate: nextEventFromAttendance.finalizedDate || new Date().toISOString().slice(0, 10),
          updatedAt: new Date().toISOString(),
        };
        setEvent(archivedEvent);
        await eventsLocalStorage.update(event.id, {
          archived: true,
          finalized: true,
          finalizedDate: archivedEvent.finalizedDate,
          updatedAt: archivedEvent.updatedAt,
          attendanceRecords: archivedEvent.attendanceRecords,
        } as Partial<Event>);
        if (Platform.OS === 'web') {
          window.alert('Event archived successfully. It now appears in the Archive tab.');
          router.back();
          return;
        }
        Alert.alert('Archived', 'Event archived successfully.', [
          {
            text: 'Back to Attendance List',
            onPress: () => router.back(),
          },
        ]);
      } catch (error) {
        console.error('Failed to archive event:', error);
        Alert.alert('Archive failed', 'Could not archive this event.');
      }
    };

    if (unchecked > 0) {
      if (Platform.OS === 'web') {
        const proceed = window.confirm(
          `${unchecked} participant${unchecked === 1 ? '' : 's'} are still unchecked.\n\nClick OK to continue archiving, or Cancel to stop.`
        );
        if (!proceed) return;
        const markUnchecked = window.confirm(
          'Click OK to mark unchecked participants as "Did not attend" before archiving.\nClick Cancel to archive as-is.'
        );
        await proceedArchive(markUnchecked);
        return;
      }
      Alert.alert(
        'Archive with unchecked participants?',
        `${unchecked} participant${unchecked === 1 ? '' : 's'} are still unchecked.`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Archive + Mark Unchecked as Did Not Attend',
            style: 'destructive',
            onPress: () => proceedArchive(true),
          },
          {
            text: 'Archive As-Is',
            onPress: () => proceedArchive(false),
          },
        ]
      );
      return;
    }

    await proceedArchive(false);
  };

  const visibleParticipants = useMemo(() => {
    if (!event) return [];
    const statusMap = getAttendanceMap(event);
    const mapped = event.participants
      .filter((participant) => !participant.deletedAt)
      .map((participant) => ({
        participant,
        state: statusMap[participant.name] || 'unchecked',
      }));

    const filtered = mapped.filter((row) => {
      if (participantView === 'unchecked') return row.state === 'unchecked';
      if (participantView === 'attended') return row.state === 'attended';
      if (participantView === 'not-attended') return row.state === 'not-attended';
      return true;
    });

    return filtered.sort((a, b) => {
      const rank = (state: AttendanceState) => (state === 'unchecked' ? 0 : state === 'attended' ? 1 : 2);
      if (rank(a.state) !== rank(b.state)) return rank(a.state) - rank(b.state);
      return a.participant.name.localeCompare(b.participant.name);
    });
  }, [event, participantView]);

  if (!event) {
    return (
      <ThemedView style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
          <Pressable onPress={() => router.back()} style={styles.backButton}>
            <IconSymbol name="chevron.left" size={24} color={tintColor} />
          </Pressable>
          <ThemedText type="title">Attendance</ThemedText>
        </View>
        <View style={styles.emptyContainer}>
          <ThemedText>Event not found.</ThemedText>
        </View>
      </ThemedView>
    );
  }

  const participantCount = event.participants.filter((p) => !p.deletedAt).length;
  const attendedRows = visibleParticipants.filter((row) => row.state === 'attended');
  const notAttendedRows = visibleParticipants.filter((row) => row.state === 'not-attended');
  const uncheckedRows = visibleParticipants.filter((row) => row.state === 'unchecked');
  const totalAttended = getCountByState('attended');
  const totalNotAttended = getCountByState('not-attended');
  const totalUnchecked = getCountByState('unchecked');

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <IconSymbol name="chevron.left" size={24} color={tintColor} />
        </Pressable>
        <ThemedText type="title">Attendance: {event.name}</ThemedText>
      </View>

      <ScrollView style={styles.content}>
        <View style={[styles.card, { backgroundColor: cardBg }]}>
          <ThemedText style={styles.metaText}>Event date: {formatEventDate(event)}</ThemedText>
          <ThemedText style={styles.metaText}>
            {totalAttended}/{participantCount} attended • {totalNotAttended} did not attend • {totalUnchecked} unchecked
          </ThemedText>

          <View style={styles.exportActions}>
            <Pressable style={[styles.exportButton, { backgroundColor: tintColor }]} onPress={exportReport}>
              <ThemedText style={styles.exportButtonText}>Export CSV</ThemedText>
            </Pressable>
            <Pressable style={[styles.exportButton, { backgroundColor: '#6b7280' }]} onPress={finalizeAttendance}>
              <ThemedText style={styles.exportButtonText}>Finalize Attendance</ThemedText>
            </Pressable>
            <Pressable style={[styles.printButton, { borderColor: tintColor }]} onPress={exportPdfReport}>
              <ThemedText style={[styles.printButtonText, { color: tintColor }]}>Export PDF</ThemedText>
            </Pressable>
            <Pressable style={[styles.exportButton, { backgroundColor: '#111827' }]} onPress={archiveEventOnly}>
              <ThemedText style={styles.exportButtonText}>Archive Event</ThemedText>
            </Pressable>
          </View>

          <View style={styles.viewControls}>
            {(['all', 'unchecked', 'attended', 'not-attended'] as ParticipantView[]).map((view) => (
              <Pressable
                key={view}
                onPress={() => setParticipantView(view)}
                style={[
                  styles.filterChip,
                  participantView === view && { backgroundColor: `${tintColor}15`, borderColor: tintColor },
                ]}
              >
                <ThemedText style={[styles.filterChipText, participantView === view && { color: tintColor }]}>
                  {view === 'all'
                    ? 'All'
                    : view === 'unchecked'
                      ? 'Unchecked'
                      : view === 'attended'
                        ? 'Attended'
                        : 'Did Not Attend'}
                </ThemedText>
              </Pressable>
            ))}
          </View>

          {visibleParticipants.length === 0 ? (
            <View style={styles.emptyContainer}>
              <ThemedText style={{ opacity: 0.5 }}>No participants in this filter</ThemedText>
            </View>
          ) : participantView === 'all' ? (
            <View style={styles.groupList}>
              <ThemedText style={styles.groupTitle}>Unchecked ({uncheckedRows.length})</ThemedText>
              <View style={styles.attendeeList}>
                {uncheckedRows.map(({ participant }) => {
                  const loadingKey = `${event.id}:${participant.name}`;
                  const isUpdating = updatingKey === loadingKey;
                  return (
                    <Pressable
                      key={participant.id}
                      onPress={() => toggleAttendance(participant.name)}
                      disabled={isUpdating}
                      style={[
                        styles.attendeeChip,
                        {
                          backgroundColor: '#f8fafc',
                          borderColor: '#d1d5db',
                          opacity: isUpdating ? 0.5 : 1,
                        },
                      ]}
                    >
                      <IconSymbol name="circle" size={14} color="#9ca3af" />
                      <ThemedText style={[styles.attendeeText, { color: '#6b7280' }]}>{participant.name}</ThemedText>
                    </Pressable>
                  );
                })}
              </View>
              <ThemedText style={styles.groupTitle}>Attended ({attendedRows.length})</ThemedText>
              <View style={styles.attendeeList}>
                {attendedRows.map(({ participant }) => {
                  const loadingKey = `${event.id}:${participant.name}`;
                  const isUpdating = updatingKey === loadingKey;
                  return (
                    <Pressable
                      key={participant.id}
                      onPress={() => toggleAttendance(participant.name)}
                      disabled={isUpdating}
                      style={[
                        styles.attendeeChip,
                        {
                          backgroundColor: '#dcfce7',
                          borderColor: '#16a34a',
                          opacity: isUpdating ? 0.5 : 1,
                        },
                      ]}
                    >
                      <IconSymbol name="checkmark.circle.fill" size={14} color="#16a34a" />
                      <ThemedText style={[styles.attendeeText, { color: '#166534' }]}>{participant.name}</ThemedText>
                    </Pressable>
                  );
                })}
              </View>
              <ThemedText style={styles.groupTitle}>Did Not Attend ({notAttendedRows.length})</ThemedText>
              <View style={styles.attendeeList}>
                {notAttendedRows.map(({ participant }) => {
                  const loadingKey = `${event.id}:${participant.name}`;
                  const isUpdating = updatingKey === loadingKey;
                  return (
                    <Pressable
                      key={participant.id}
                      onPress={() => toggleAttendance(participant.name)}
                      disabled={isUpdating}
                      style={[
                        styles.attendeeChip,
                        {
                          backgroundColor: '#fee2e2',
                          borderColor: '#dc2626',
                          opacity: isUpdating ? 0.5 : 1,
                        },
                      ]}
                    >
                      <IconSymbol name="xmark.circle.fill" size={14} color="#dc2626" />
                      <ThemedText style={[styles.attendeeText, { color: '#991b1b' }]}>{participant.name}</ThemedText>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          ) : (
            <View style={styles.attendeeList}>
              {visibleParticipants.map(({ participant, state }) => {
                const loadingKey = `${event.id}:${participant.name}`;
                const isUpdating = updatingKey === loadingKey;
                const visual =
                  state === 'attended'
                    ? {
                        bg: '#dcfce7',
                        border: '#16a34a',
                        text: '#166534',
                        icon: 'checkmark.circle.fill',
                        iconColor: '#16a34a',
                      }
                    : state === 'not-attended'
                      ? {
                          bg: '#fee2e2',
                          border: '#dc2626',
                          text: '#991b1b',
                          icon: 'xmark.circle.fill',
                          iconColor: '#dc2626',
                        }
                      : {
                          bg: '#f8fafc',
                          border: '#d1d5db',
                          text: '#6b7280',
                          icon: 'circle',
                          iconColor: '#9ca3af',
                        };
                return (
                  <Pressable
                    key={participant.id}
                    onPress={() => toggleAttendance(participant.name)}
                    disabled={isUpdating}
                    style={[
                      styles.attendeeChip,
                      {
                        backgroundColor: visual.bg,
                        borderColor: visual.border,
                        opacity: isUpdating ? 0.5 : 1,
                      },
                    ]}
                  >
                    <IconSymbol name={visual.icon as any} size={14} color={visual.iconColor} />
                    <ThemedText style={[styles.attendeeText, { color: visual.text }]}>{participant.name}</ThemedText>
                  </Pressable>
                );
              })}
            </View>
          )}
        </View>

        <View style={{ height: insets.bottom + 80 }} />
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 16,
    gap: 12,
  },
  backButton: { padding: 4 },
  content: { flex: 1, paddingHorizontal: 20 },
  card: { padding: 16, borderRadius: 12, marginBottom: 12 },
  metaText: { fontSize: 13, opacity: 0.75, marginBottom: 4 },
  exportActions: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: 12,
    marginBottom: 16,
  },
  exportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 12,
    minWidth: 150,
  },
  exportButtonText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  printButton: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  printButtonText: { fontSize: 14, fontWeight: '600' },
  viewControls: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  filterChip: {
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  filterChipText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6b7280',
  },
  groupList: { gap: 12 },
  groupTitle: { fontSize: 13, fontWeight: '700', opacity: 0.8 },
  attendeeList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  attendeeChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  attendeeText: { fontSize: 12, fontWeight: '500' },
  emptyContainer: {
    paddingVertical: 24,
    alignItems: 'center',
  },
});
