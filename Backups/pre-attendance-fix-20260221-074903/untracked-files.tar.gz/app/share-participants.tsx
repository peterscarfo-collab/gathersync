import { useState, useEffect } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, View, Share, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Clipboard from 'expo-clipboard';
import * as Haptics from 'expo-haptics';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useThemeColor } from '@/hooks/use-theme-color';
import { useEvent } from '@/hooks/use-instant-events';
import { eventsLocalStorage } from '@/lib/local-storage';
import { getMonthName } from '@/lib/calendar-utils';
import { buildPublicEventParticipantUrl } from '@/lib/public-links';
import type { Event } from '@/types/models';

export default function ShareParticipantsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { eventId } = useLocalSearchParams<{ eventId: string }>();

  const { event: liveEvent } = useEvent(eventId ?? null);
  const [event, setEvent] = useState<Event | null>(null);
  const [selectedParticipants, setSelectedParticipants] = useState<Set<string>>(new Set());

  const tintColor = useThemeColor({}, 'tint');
  const backgroundColor = useThemeColor({}, 'background');
  const surfaceColor = useThemeColor({}, 'surface');
  const textSecondaryColor = useThemeColor({}, 'textSecondary');

  useEffect(() => {
    if (liveEvent) {
      setEvent(liveEvent);
      setSelectedParticipants(new Set(liveEvent.participants.map(p => p.id)));
    } else if (eventId) {
      eventsLocalStorage.getById(eventId).then(loaded => {
        if (loaded) {
          setEvent(loaded);
          setSelectedParticipants(new Set(loaded.participants.map(p => p.id)));
        }
      });
    }
  }, [eventId, liveEvent]);

  const toggleParticipant = (participantId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedParticipants(prev => {
      const newSet = new Set(prev);
      if (newSet.has(participantId)) {
        newSet.delete(participantId);
      } else {
        newSet.add(participantId);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const participants = event?.participants || [];

    if (selectedParticipants.size === participants.length) {
      setSelectedParticipants(new Set());
    } else {
      setSelectedParticipants(new Set(participants.map(p => p.id)));
    }
  };

  const buildShareMessage = (): string => {
    if (!event) return '';

    const selected = event.participants.filter(p => selectedParticipants.has(p.id));
    const messages = selected.map(participant => {
      const webUrl = buildPublicEventParticipantUrl(event.id, participant.name);

      const eventInfo =
        event.eventType === 'fixed'
          ? `${event.fixedDate}${event.fixedTime ? ' at ' + event.fixedTime : ''}`
          : `${getMonthName(event.month)} ${event.year}`;

      return `Hi ${participant.name},\n\n📅 ${event.name}\n${eventInfo}${event.venueName ? `\n📍 ${event.venueName}` : ''}\n\nView and update your availability:\n${webUrl}`;
    });

    return messages.join('\n\n---\n\n');
  };

  const handleShare = async () => {
    if (!event) return;

    if (selectedParticipants.size === 0) {
      if (Platform.OS === 'web') {
        alert('Please select at least one participant.');
      } else {
        Alert.alert('No Selection', 'Please select at least one participant to share with.');
      }
      return;
    }

    const message = buildShareMessage();
    if (!message) return;

    try {
      if (Platform.OS === 'web' && typeof navigator?.share === 'function') {
        await navigator.share({
          title: `${event.name} - Share with Participants`,
          text: message,
        });
      } else if (Platform.OS === 'web') {
        await Clipboard.setStringAsync(message);
        alert('Invitations copied to clipboard! Paste into your email or messages app to send.');
      } else {
        await Share.share({
          message,
          title: `${event.name} - Share with Participants`,
        });
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error: any) {
      if (error?.name === 'AbortError') return;
      console.error('Error sharing:', error);
      if (Platform.OS === 'web') {
        try {
          await Clipboard.setStringAsync(message);
          alert('Invitations copied to clipboard! Paste into your email or messages app to send.');
        } catch (clipErr) {
          Alert.alert('Share Failed', 'Could not copy. Please try again.');
        }
      }
    }
  };

  const handleCopy = async () => {
    if (!event) return;

    if (selectedParticipants.size === 0) {
      if (Platform.OS === 'web') {
        alert('Please select at least one participant.');
      } else {
        Alert.alert('No Selection', 'Please select at least one participant to copy.');
      }
      return;
    }

    const message = buildShareMessage();
    if (!message) return;

    try {
      await Clipboard.setStringAsync(message);
      if (Platform.OS === 'web') {
        alert('Invitations copied to clipboard! Paste into Messages, Mail, or any app to send.');
      } else {
        Alert.alert('Copied', 'Invitations copied to clipboard');
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error('Error copying:', error);
    }
  };

  if (!event) {
    return (
      <ThemedView style={[styles.container, { backgroundColor }]}>
        <ThemedText>Loading...</ThemedText>
      </ThemedView>
    );
  }

  const allSelected =
    event.participants.length > 0 &&
    selectedParticipants.size === event.participants.length;

  return (
    <ThemedView style={[styles.container, { backgroundColor }]}>
      <View
        style={[
          styles.header,
          {
            paddingTop: Math.max(insets.top, 16),
            paddingBottom: 16,
          },
        ]}
      >
        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            router.back();
          }}
          hitSlop={8}
        >
          <IconSymbol name="chevron.left" size={28} color={tintColor} />
        </Pressable>
        <ThemedText type="subtitle" style={styles.headerTitle}>
          Share with Participants
        </ThemedText>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={[
          styles.contentContainer,
          { paddingBottom: Math.max(insets.bottom, 16) + 120 },
        ]}
      >
        {event.participants.length > 0 ? (
          <>
            <View style={[styles.selectAllCard, { backgroundColor: surfaceColor }]}>
              <Pressable style={styles.selectAllButton} onPress={toggleSelectAll}>
                <View
                  style={[
                    styles.checkbox,
                    { borderColor: tintColor },
                    allSelected && { backgroundColor: tintColor },
                  ]}
                >
                  {allSelected && (
                    <IconSymbol name="checkmark" size={16} color="#FFFFFF" />
                  )}
                </View>
                <ThemedText type="defaultSemiBold">
                  Select All ({event.participants.length})
                </ThemedText>
              </Pressable>
              <ThemedText style={[styles.hint, { color: textSecondaryColor }]}>
                {selectedParticipants.size} selected
              </ThemedText>
            </View>

            <View style={styles.participantsList}>
              {event.participants.map(participant => (
                <Pressable
                  key={participant.id}
                  style={[styles.participantCard, { backgroundColor: surfaceColor }]}
                  onPress={() => toggleParticipant(participant.id)}
                >
                  <View
                    style={[
                      styles.checkbox,
                      { borderColor: tintColor },
                      selectedParticipants.has(participant.id) && {
                        backgroundColor: tintColor,
                      },
                    ]}
                  >
                    {selectedParticipants.has(participant.id) && (
                      <IconSymbol name="checkmark" size={16} color="#FFFFFF" />
                    )}
                  </View>
                  <View style={styles.participantInfo}>
                    <ThemedText type="defaultSemiBold">{participant.name}</ThemedText>
                    {(participant.email || participant.phone) && (
                      <ThemedText
                        style={[styles.contact, { color: textSecondaryColor }]}
                      >
                        {[participant.email, participant.phone]
                          .filter(Boolean)
                          .join(' • ')}
                      </ThemedText>
                    )}
                  </View>
                </Pressable>
              ))}
            </View>
          </>
        ) : (
          <View style={[styles.emptyCard, { backgroundColor: surfaceColor }]}>
            <IconSymbol name="person.2.fill" size={48} color={textSecondaryColor} />
            <ThemedText type="subtitle" style={styles.emptyTitle}>
              No Participants
            </ThemedText>
            <ThemedText style={[styles.emptyText, { color: textSecondaryColor }]}>
              Add participants to this event before sharing.
            </ThemedText>
          </View>
        )}
      </ScrollView>

      {event.participants.length > 0 && (
        <View
          style={[
            styles.footer,
            {
              paddingBottom: Math.max(insets.bottom, 16),
              backgroundColor: backgroundColor,
            },
          ]}
        >
          <View style={styles.buttonRow}>
            <Pressable
              style={[
                styles.copyButton,
                { borderColor: tintColor },
                selectedParticipants.size === 0 && styles.buttonDisabled,
              ]}
              onPress={handleCopy}
              disabled={selectedParticipants.size === 0}
            >
              <IconSymbol name="doc.on.doc" size={20} color={tintColor} />
              <ThemedText style={[styles.copyButtonText, { color: tintColor }]}>
                Copy
              </ThemedText>
            </Pressable>
            <Pressable
              style={[
                styles.shareButton,
                { backgroundColor: tintColor },
                selectedParticipants.size === 0 && styles.buttonDisabled,
              ]}
              onPress={handleShare}
              disabled={selectedParticipants.size === 0}
            >
              <IconSymbol name="square.and.arrow.up" size={20} color="#FFFFFF" />
              <ThemedText style={styles.shareButtonText}>
                Share ({selectedParticipants.size})
              </ThemedText>
            </Pressable>
          </View>
        </View>
      )}
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.05)',
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
  },
  selectAllCard: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  selectAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  hint: {
    fontSize: 14,
    lineHeight: 20,
  },
  participantsList: {
    gap: 8,
  },
  participantCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 12,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  participantInfo: {
    flex: 1,
  },
  contact: {
    fontSize: 14,
    lineHeight: 20,
    marginTop: 2,
  },
  emptyCard: {
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
  },
  emptyTitle: {
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
  footer: {
    paddingHorizontal: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0, 0, 0, 0.05)',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
  },
  copyButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 2,
  },
  shareButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 12,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  copyButtonText: {
    fontSize: 16,
    lineHeight: 24,
    fontWeight: '600',
  },
  shareButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    lineHeight: 24,
    fontWeight: '600',
  },
});
