// @ts-nocheck
import { useEffect, useState } from 'react';
import { Alert, Platform, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';

import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { useThemeColor } from '@/hooks/use-theme-color';
import { eventsLocalStorage, snapshotsLocalStorage } from '@/lib/local-storage';

export default function BackupDetailScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ snapshotId?: string }>();
  const snapshotId = Array.isArray(params.snapshotId) ? params.snapshotId[0] : params.snapshotId;

  const tintColor = useThemeColor({}, 'tint');
  const backgroundColor = useThemeColor({}, 'background');
  const surfaceColor = useThemeColor({}, 'surface');
  const textSecondaryColor = useThemeColor({}, 'textSecondary');

  const [snapshot, setSnapshot] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const run = async () => {
      try {
        const all = await snapshotsLocalStorage.getAll();
        const found = all.find((s: any) => s.id === snapshotId) || null;
        setSnapshot(found);
      } finally {
        setLoading(false);
      }
    };
    run();
  }, [snapshotId]);

  const restoreBackupNow = async () => {
    if (!snapshot) return;
    const backupEvent = snapshot.event || snapshot.eventData;
    const backupEventId = snapshot.eventId || backupEvent?.id;
    if (!backupEvent || !backupEventId) {
      Alert.alert('Error', 'This backup is missing event data and cannot be restored.');
      return;
    }

    try {
      const existingEvent = await eventsLocalStorage.getById(backupEventId);
      if (existingEvent) {
        await eventsLocalStorage.update(backupEventId, {
          ...backupEvent,
          updatedAt: new Date().toISOString(),
        });
      } else {
        const { id, createdAt, updatedAt, ...eventData } = backupEvent;
        await eventsLocalStorage.add(eventData);
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      if (Platform.OS === 'web') {
        alert('Backup restored successfully.');
      } else {
        Alert.alert('Restored', 'Backup restored successfully.');
      }
      router.push({ pathname: '/event-detail' as any, params: { eventId: backupEventId } });
    } catch (error) {
      console.error('Restore backup failed:', error);
      Alert.alert('Error', 'Failed to restore backup.');
    }
  };

  const handleRestore = async () => {
    if (!snapshot) return;
    const message = `Restore "${snapshot.name}" from ${new Date(snapshot.savedAt).toLocaleString()}?`;
    if (Platform.OS === 'web') {
      const confirmed = window.confirm(message);
      if (!confirmed) return;
      await restoreBackupNow();
      return;
    }
    Alert.alert('Restore Backup', message, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Restore', onPress: () => restoreBackupNow() },
    ]);
  };

  if (loading) {
    return (
      <ThemedView style={[styles.container, { backgroundColor, justifyContent: 'center', alignItems: 'center' }]}>
        <ThemedText>Loading backup...</ThemedText>
      </ThemedView>
    );
  }

  if (!snapshot) {
    return (
      <ThemedView style={[styles.container, { backgroundColor, justifyContent: 'center', alignItems: 'center', padding: 20 }]}>
        <ThemedText type="subtitle">Backup not found</ThemedText>
        <ThemedText style={[styles.metaText, { color: textSecondaryColor, textAlign: 'center' }]}>
          This backup may have been removed.
        </ThemedText>
      </ThemedView>
    );
  }

  const event = snapshot.event || snapshot.eventData || {};
  const participants = event.participants || [];
  const currentEventId = snapshot.eventId || event.id;

  return (
    <ThemedView style={[styles.container, { backgroundColor }]}>
      <View style={[styles.header, { paddingTop: Math.max(insets.top, 16) }]}>
        <Pressable onPress={() => router.back()} style={styles.backButton}>
          <IconSymbol name="chevron.left" size={24} color={tintColor} />
        </Pressable>
        <ThemedText type="title">Backup Detail</ThemedText>
        <View style={{ width: 28 }} />
      </View>

      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: Math.max(insets.bottom, 20) + 20 }]}>
        <View style={[styles.card, { backgroundColor: surfaceColor }]}>
          <ThemedText type="subtitle">{snapshot.name}</ThemedText>
          <ThemedText style={[styles.metaText, { color: textSecondaryColor }]}>
            Backup taken: {new Date(snapshot.savedAt).toLocaleString()}
          </ThemedText>
          <ThemedText style={[styles.metaText, { color: textSecondaryColor }]}>
            Event month: {event.month}/{event.year}
          </ThemedText>
          <ThemedText style={[styles.metaText, { color: textSecondaryColor }]}>
            Participants at backup time: {participants.length}
          </ThemedText>
        </View>

        <View style={[styles.card, { backgroundColor: surfaceColor }]}>
          <ThemedText type="defaultSemiBold" style={{ marginBottom: 8 }}>Participants in this backup</ThemedText>
          {participants.length === 0 ? (
            <ThemedText style={[styles.metaText, { color: textSecondaryColor }]}>No participants in this backup.</ThemedText>
          ) : (
            participants.map((p: any, idx: number) => (
              <View key={`${p.id || p.name}-${idx}`} style={styles.participantRow}>
                <ThemedText>{p.name || 'Unnamed participant'}</ThemedText>
                <ThemedText style={[styles.metaText, { color: textSecondaryColor }]}>
                  {p.rsvpStatus || 'no-response'}
                </ThemedText>
              </View>
            ))
          )}
        </View>

        <Pressable style={[styles.primaryButton, { backgroundColor: tintColor }]} onPress={handleRestore}>
          <ThemedText style={styles.primaryButtonText}>Restore This Backup</ThemedText>
        </Pressable>
        <Pressable
          style={[styles.secondaryButton, { borderColor: tintColor }]}
          onPress={() => currentEventId && router.push({ pathname: '/event-detail' as any, params: { eventId: currentEventId } })}
        >
          <ThemedText style={[styles.secondaryButtonText, { color: tintColor }]}>Open Current Event</ThemedText>
        </Pressable>
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  backButton: { padding: 4 },
  content: { paddingHorizontal: 16, gap: 12 },
  card: { borderRadius: 14, padding: 16 },
  metaText: { fontSize: 13, marginTop: 4 },
  participantRow: {
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#d1d5db',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  primaryButton: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 6,
  },
  primaryButtonText: { color: '#fff', fontWeight: '700' },
  secondaryButton: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1.5,
  },
  secondaryButtonText: { fontWeight: '700' },
});
